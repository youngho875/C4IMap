#include "pch.h"
#include "C4IMap.h"
#include "MainFrm.h"
#include "C4IMapView.h"
#include "OutputSearchList.h"

// COutputSearchList

IMPLEMENT_DYNAMIC(COutputSearchList, CMFCListCtrl)

COutputSearchList::COutputSearchList()
{
	m_emListType = SEARCHLIST_NONE;
	m_nColumnCount = 0;
}

COutputSearchList::~COutputSearchList()
{
	//ClearSearch();
}


BEGIN_MESSAGE_MAP(COutputSearchList, CMFCListCtrl)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_POPUP_OUTPUT_COPY, OnResultCopy)
	ON_UPDATE_COMMAND_UI(ID_POPUP_OUTPUT_COPY, OnUpdateResultCopy)
	ON_COMMAND(ID_POPUP_OUTPUT_MOVE, OnResultMove)
	ON_UPDATE_COMMAND_UI(ID_POPUP_OUTPUT_MOVE, OnUpdateResultMove)
	ON_NOTIFY_REFLECT(NM_CLICK, &COutputSearchList::OnNMClick)
	ON_WM_MOUSEWHEEL()
END_MESSAGE_MAP()



// COutputSearchList �޽��� ó�����Դϴ�.



void COutputSearchList::OnContextMenu(CWnd* pWnd, CPoint point)
{
	HINSTANCE hOrgInstance = AfxGetResourceHandle();
	AfxSetResourceHandle(AfxGetInstanceHandle());

	CMenu menu;
	menu.LoadMenu(IDR_POPUP_SEARCH);

	CMenu* pSumMenu = menu.GetSubMenu(0);

	if (AfxGetMainWnd()->IsKindOf(RUNTIME_CLASS(CFrameWndEx)))
	{
		CMFCPopupMenu* pPopupMenu = new CMFCPopupMenu;

		if (!pPopupMenu->Create(this, point.x, point.y, (HMENU)pSumMenu->m_hMenu, FALSE, TRUE))
			return;

		((CFrameWndEx*)AfxGetMainWnd())->OnShowPopupMenu(pPopupMenu);
		UpdateDialogControls(this, FALSE);
	}

	SetFocus();
	AfxSetResourceHandle(hOrgInstance);
}


void COutputSearchList::OnResultCopy()
{
	POSITION pos = GetFirstSelectedItemPosition();

	if (pos != NULL)
	{
		CString sResult;

		CWaitCursor wait;
		int nItem, nCount = 0;
		CString strColumn;

		MAPSEARCH_LAYER_RESULT stResult = m_vResult.at(0);
		for (int i = 0; i < (int)stResult.vInfo.size(); i++)
		{
			strColumn += stResult.vInfo.at(i).strTitle;
			strColumn += _T("\t");
		}

		if (strColumn.IsEmpty() == FALSE)
			strColumn += _T("\r\n");

		while (pos)
		{
			nItem = GetNextSelectedItem(pos);
			if (0 != nCount)
				sResult += _T("\r\n");

			for (int i = 0; i < m_nColumnCount; ++i)
			{
				sResult += GetItemText(nItem, i);
				if (i != m_nColumnCount - 1)
					sResult += _T("\t");
			}

			++nCount;
		}

		sResult = strColumn + sResult;

		if (OpenClipboard())
		{
			EmptyClipboard();

			int nLen = sResult.GetLength() * sizeof(WCHAR) + 1;
			HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE, nLen);
			LPBYTE pGlobalData = (LPBYTE)GlobalLock(hGlobal);

			USES_CONVERSION_EX;
			CopyMemory(pGlobalData, T2CW_EX(sResult, _ATL_SAFE_ALLOCA_DEF_THRESHOLD), nLen);
			SetClipboardData(CF_UNICODETEXT, hGlobal);

			GlobalUnlock(hGlobal);
			GlobalFree(hGlobal);
			CloseClipboard();
		}
	}
}

void COutputSearchList::OnUpdateResultCopy(CCmdUI* pCmdUI)
{
	if (0 < GetItemCount())
		pCmdUI->Enable(TRUE);
	else
		pCmdUI->Enable(FALSE);
}

void COutputSearchList::OnResultMove()
{
	int nSelectIndex = GetSelectionMark();

	if (nSelectIndex < (int)m_vResult.size())
	{
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();

		if (pFrame)
		{
			CC4IMapView* pView = (CC4IMapView*)pFrame->GetActiveView();
			if (pView)
			{
				switch (m_emListType)
				{
				case SEARCHLIST_NONE:// = 0, // ��� ����
				case SEARCHLIST_SCREEN://,	 // ���� �˻� ���
				{
					//pView->SendMessage(OUTPUT_SEARCH_AREA_MOVE, (WPARAM)nSelectIndex);
					break;
				}
				case SEARCHLIST_NAME://,	 // �˻��� �˻� ���
				{
					//pView->SendMessage(OUTPUT_SEARCH_NAME_MOVE, (WPARAM)nSelectIndex);
					break;
				}
				case SEARCHLIST_COP_IMPORTANT://,	// ��Ȳ�� �߿䵵�ÿ��
				case SEARCHLIST_COP_ALWAYS://,	// ��Ȳ�� ��ý������
				case SEARCHLIST_COP:
				{
					if (nSelectIndex < (int)m_vResult.size())
					{
						MAPSEARCH_LAYER_RESULT stResult = m_vResult.at(nSelectIndex);

						MAPSEARCH_LAYER_SELECT stSelectInfo;
						stSelectInfo.nIndex = nSelectIndex;
						stSelectInfo.strTitle = m_strTitle;
						//pView->SendMessage(OUTPUT_SEARCH_COP_MOVECENTER, (WPARAM)&stResult, (LPARAM)&stSelectInfo);
					}
					break;
				}
				}
			}
		}
	}
}

void COutputSearchList::OnUpdateResultMove(CCmdUI* pCmdUI)
{
	if (GetSelectedCount() == 1)
		pCmdUI->Enable(TRUE);
	else
		pCmdUI->Enable(FALSE);
}

void COutputSearchList::ClearSearch()
{
	m_emListType = SEARCHLIST_NONE;	// ��� ����

	if (GetSafeHwnd())
		DeleteAllItems();

	for (int i = 0; i < m_nColumnCount; i++)
		DeleteColumn(0);

	for (int j = 0; j < (int)m_vResult.size(); j++)
	{
		MAPSEARCH_LAYER_RESULT resultInfo = m_vResult.at(j);
		resultInfo.vInfo.clear();
	}

	m_nColumnCount = 0;
	m_vResult.clear();
	m_mapListColumn.RemoveAll();
	m_strTitle = "";
}

void COutputSearchList::SetSearchResult(vector<MAPSEARCH_LAYER_RESULT>& vResult)
{
	if (0 < (int)vResult.size())
	{
		MAPSEARCH_LAYER_RESULT stResult = vResult.at(0);

		m_nColumnCount = 1;
		InsertColumn(0, "", LVCFMT_CENTER, 0);

		for (int i = 0; i < (int)stResult.vInfo.size(); i++)
		{
			MAPSEARCH_LAYER_INFO stInfo = stResult.vInfo.at(i);
			InsertColumn(m_nColumnCount, stInfo.strTitle, LVCFMT_CENTER, 100);

			CString strColumnIndex;
			strColumnIndex.Format("%d", m_nColumnCount++);
			m_mapListColumn.SetAt(stInfo.strTitle, strColumnIndex);
		}
	}

	for (int i = 0; i < (int)vResult.size(); i++)
	{
		MAPSEARCH_LAYER_RESULT stResult = vResult.at(i);
		m_vResult.push_back(stResult);

		CString strIndex;
		strIndex.Format("%d", stResult.nIndex);

		InsertItem(i, strIndex);

		for (int j = 0; j < (int)stResult.vInfo.size(); j++)
		{
			MAPSEARCH_LAYER_INFO stInfo = stResult.vInfo.at(j);

			CString strColumnIndex;

			if (m_mapListColumn.Lookup(stInfo.strTitle, strColumnIndex))
			{
				SetItemText(i, atoi(strColumnIndex), stInfo.strContent);
			}
			else
			{
				InsertColumn(m_nColumnCount, stInfo.strTitle, LVCFMT_CENTER, 100);

				CString strColumnIndex;
				strColumnIndex.Format("%d", m_nColumnCount++);
				m_mapListColumn.SetAt(stInfo.strTitle, strColumnIndex);
				SetItemText(i, atoi(strColumnIndex), stInfo.strContent);
			}
		}
	}

}

void COutputSearchList::SetSearchScreen(CString strCategory, CString strLayer, vector<MAPSEARCH_LAYER_RESULT>& vResult)
{
	ClearSearch();
	m_emListType = SEARCHLIST_SCREEN;	// ���� �˻� ���
	m_strTitle = strCategory + "-" + strLayer;
	SetSearchResult(vResult);

}

void COutputSearchList::SetSearchName(CString strLayer, vector<MAPSEARCH_LAYER_RESULT>& vResult)
{
	ClearSearch();
	m_emListType = SEARCHLIST_NAME;	// �˻��� �˻� ���
	m_strTitle = strLayer;
	SetSearchResult(vResult);
}

void COutputSearchList::SetSearchCOP(CString strLayer, vector<MAPSEARCH_LAYER_RESULT>& vResult, SEARCHLIST_KIND emListType)
{
	ClearSearch();
	m_emListType = emListType;	// �˻��� �˻� ���
	m_strTitle = strLayer;
	SetSearchResult(vResult);
}

void COutputSearchList::OnNMClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	// ��� ���� ���� �� �Ӽ� ������ ���
	if (GetSelectedCount() == 1)
	{
		int nSelectIndex = GetSelectionMark();

		if (nSelectIndex < (int)m_vResult.size())
		{
			MAPSEARCH_LAYER_RESULT stResult = m_vResult.at(nSelectIndex);

			MAPSEARCH_LAYER_SELECT stSelectInfo;
			stSelectInfo.nIndex = nSelectIndex;
			stSelectInfo.strTitle = m_strTitle;

			CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();

			if (pFrame)
			{
				CC4IMapView* pView = (CC4IMapView*)pFrame->GetActiveView();
				if (pView)
				{
					switch (m_emListType)
					{
					case SEARCHLIST_NONE:// = 0, // ��� ����
					case SEARCHLIST_SCREEN://,	 // ���� �˻� ���
					{
						//pView->SendMessage(OUTPUT_SEARCH_AREA_SELECT, (WPARAM)&stResult, (LPARAM)&stSelectInfo);
						//pView->SendMessage(OUTPUT_SEARCH_AREA_MOVE, (WPARAM)nSelectIndex);
						break;
					}
					case SEARCHLIST_NAME://,	 // �˻��� �˻� ���
					{
						//pView->SendMessage(OUTPUT_SEARCH_NAME_SELECT, (WPARAM)&stResult, (LPARAM)&stSelectInfo);
						//pView->SendMessage(OUTPUT_SEARCH_NAME_MOVE, (WPARAM)nSelectIndex);
						break;
					}
					case SEARCHLIST_COP_IMPORTANT://,	// ��Ȳ�� �߿䵵�ÿ��
					case SEARCHLIST_COP_ALWAYS://,	// ��Ȳ�� ��ý������
					case SEARCHLIST_COP:
					{
						//pView->SendMessage(OUTPUT_SEARCH_NAME_SELECT, (WPARAM)&stResult, (LPARAM)&stSelectInfo);
						//pView->SendMessage(OUTPUT_SEARCH_COP_MOVE, (WPARAM)&stResult, (LPARAM)&stSelectInfo);
						break;
					}
					}
				}
			}
		}
	}

	*pResult = 0;
}



BOOL COutputSearchList::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	CRect rt;
	GetClientRect(rt);
	ClientToScreen(rt);

	// ���콺 �� �̵� �� ���� �� �� ��� �������� ��Ŀ�� �̵�
	if (!rt.PtInRect(pt))
	{
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
		if (pFrame != NULL)
			pFrame->SetFocus();
		return FALSE;
	}

	return CMFCListCtrl::OnMouseWheel(nFlags, zDelta, pt);
}