#pragma once


class CViewList : public CListCtrl
{
public:
	CViewList();

protected:
	BOOL CopyToClipboard(LPCTSTR lpszSeparator = _T("\t"), BOOL bCopyHeaderText = FALSE);

	// �������Դϴ�.
protected:

	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);

	// �����Դϴ�.
public:
	virtual ~CViewList();

protected:
	DECLARE_MESSAGE_MAP()

};

