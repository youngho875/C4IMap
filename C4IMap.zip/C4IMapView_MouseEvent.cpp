﻿#include "pch.h"
#include "DisplayProjection.h"
#include "C4IMapViewHeader.h"

#include <iostream>



char		globalLat[10] = CENTERLAT;
char		globalLong[10] = CENTERLONG;


void CC4IMapView::OnMouseMove(UINT nFlags, CPoint point)
{
    if (m_analysis.Move(point, m_pCoordMgr))
    {
        Invalidate(FALSE);
        return;
    }
    if(m_rotationDragging)
	{
        DisplayProjection().SetAngle(m_pCoordMgr,m_rotationStartAngle+(point.x-m_rotationStart.x)*0.5);
        Invalidate(FALSE);
		return;
    }
    if(m_localOverlay.Move(point,m_pCoordMgr))
	{
		Invalidate(FALSE);
		return;
	}
	CView::OnMouseMove(nFlags, point);

	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	UpdateStatusBar(point);

	if (m_bPanning && nFlags == MK_LBUTTON)
	{
		mb_moving = TRUE;

		if (m_ptPrevPoint == point)
			return;

		//CKB 메인 DC만 그리도록 해서 성능 확보  
		m_ptPrevPoint.x = point.x - m_ptZoomWindowLT.x;
		m_ptPrevPoint.y = point.y - m_ptZoomWindowLT.y;

		draw_maindc_only(m_ptPrevPoint);

		return;
	}

	if (m_bOnZoom == TRUE && nFlags == MK_LBUTTON + MK_SHIFT)
	{
		// Draging for Zooming
		CRect rectClient;
		GetClientRect(&rectClient);

		/////////////////////////////////////////////////////////
		// Zoom Rect를 그리고 계산한다. 
		/////////////////////////////////////////////////////////

		//	1. 이전의 Rect를 지운다. 
		DrawZoomRect(m_dcMain, CRect(m_ptZoomStart, m_ptZoomEnd));

		//	2. 새로운 Rect를 계산하고 예외처리를 한다.  
		m_ptZoomEnd = point;
		if (!rectClient.PtInRect(m_ptZoomEnd))
		{
			if (m_ptZoomEnd.x < rectClient.left)
				m_ptZoomEnd.x = rectClient.left;
			else if (m_ptZoomEnd.x > rectClient.right)
				m_ptZoomEnd.x = rectClient.right - 1;

			if (m_ptZoomEnd.y < rectClient.top)
				m_ptZoomEnd.y = rectClient.top;
			else if (m_ptZoomEnd.y > rectClient.bottom)
				m_ptZoomEnd.y = rectClient.bottom - 1;
		}
		//	3. 새로운 Rect를 그린다.  
		DrawZoomRect(m_dcMain, CRect(m_ptZoomStart, m_ptZoomEnd));
	}
	//CView::OnMouseMove(nFlags, point);
}


void CC4IMapView::OnLButtonDown(UINT nFlags, CPoint point)
{
    if (GetMouseState() == MOUSE_ZOOMIN || GetMouseState() == MOUSE_ZOOMOUT)
    {
        SetFocus();
        m_bPanning = m_bOnZoom = m_bMapMove = mb_moving = FALSE;
        return;
    }
    if (m_analysis.Active())
    {
        SetFocus();
        return;
    }
    if(m_localOverlay.Begin(point,m_pCoordMgr)){SetFocus();SetCapture();Invalidate(FALSE);return;}
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	
	m_bPanning = (nFlags & (MK_SHIFT | MK_CONTROL)) == 0;
	
	m_ptZoomStart = m_ptZoomEnd = point;
	SetCapture();
	m_bOnZoom = (nFlags & MK_SHIFT) != 0;

	m_ptPrevPoint = point;
	m_ptMapMoveFirstPoint = point;
	if (nFlags == MK_LBUTTON)
	{
		m_ptZoomWindowLT = m_ptZoomWindowBR = point;
		m_bMapMove = TRUE;

		HCURSOR hCursor;
		hCursor = AfxGetApp()->LoadStandardCursor(IDC_SIZEALL);
		SetCursor(hCursor);
		SetCapture();
	}



	CView::OnLButtonDown(nFlags, point);
}


void CC4IMapView::OnLButtonUp(UINT nFlags, CPoint point)
{
    if (GetMouseState() == MOUSE_ZOOMIN || GetMouseState() == MOUSE_ZOOMOUT)
    {
        if (GetCapture() == this)
            ReleaseCapture();
        ZoomAtPoint(point, GetMouseState() == MOUSE_ZOOMIN);
        return;
    }
    if (m_analysis.Click(point, m_pCoordMgr))
    {
        Invalidate(FALSE);
        return;
    }
    if(m_localOverlay.End(point,m_pCoordMgr))
	{
        RefreshOverlayLayers();
		ReleaseCapture();
		Invalidate(FALSE);
		return;
	}
    const bool localClick=!m_bOnZoom && !(nFlags&(MK_SHIFT|MK_CONTROL)) && abs(point.x-m_ptMapMoveFirstPoint.x)<=3 && abs(point.y-m_ptMapMoveFirstPoint.y)<=3;
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	CView::OnLButtonUp(nFlags, point);

	ReleaseCapture();
	CRect		rc;


	CClientDC	dc(this);
	CPoint ClinetPoint = point;

	m_bPanning = FALSE;
	mb_moving = FALSE;//

	if (m_bMapMove && point != m_ptMapMoveFirstPoint && nFlags != MK_CONTROL && nFlags != MK_SHIFT)
	{
		CPoint ptNewPoint;
		ptNewPoint.x = -point.x + m_ptMapMoveFirstPoint.x;
		ptNewPoint.y = -point.y + m_ptMapMoveFirstPoint.y;
		m_pCoordMgr->m_fCenterX -= ptNewPoint.x;
		m_pCoordMgr->m_fCenterY -= ptNewPoint.y;
		//m_pOverlayThread->RePosition();
		//if (m_pDlgOverlayControler->IsWindowVisible() == TRUE)
		//	m_pDlgOverlayControler->UpDateGridDraw();


		DrawSituation(TRUE, TRUE, TRUE, TRUE);
		m_bMapMove = FALSE;
		HCURSOR hCursor;
		hCursor = AfxGetApp()->LoadStandardCursor(IDC_ARROW);
		SetCursor(hCursor);

	} 

	double fWorldX, fWorldY;
	m_pCoordMgr->ScreenXY2WorldXY(point.x, point.y, &fWorldX, &fWorldY);
	m_Coord.x_y_to_degrees_lat_long_str(fWorldX, fWorldY, globalLat, globalLong);


	// 점 그리기
	CBrush pBrush, * pOldBrush;
	pBrush.CreateSolidBrush(RGB(255, 0, 0));
	pOldBrush = m_dcMain->SelectObject(&pBrush);
	m_dcMain->Ellipse(point.x - 4, point.y - 4, point.x + 4, point.y + 4);
	m_dcMain->SelectObject(pOldBrush);

	CPoint ptTempo;
	if (m_bOnZoom)
	{
		if (m_ptZoomEnd.x < m_ptZoomStart.x)
		{
			ptTempo.x = m_ptZoomEnd.x;
			m_ptZoomEnd.x = m_ptZoomStart.x;
			m_ptZoomStart.x = ptTempo.x;
		}
		if (m_ptZoomEnd.y < m_ptZoomStart.y)
		{
			ptTempo.y = m_ptZoomEnd.y;
			m_ptZoomEnd.y = m_ptZoomStart.y;
			m_ptZoomStart.y = ptTempo.y;
		}

		CRect rectZoom = CRect(m_ptZoomStart, m_ptZoomEnd);
		DrawZoomRect(m_dcMain, rectZoom);
		ReleaseCapture();
		m_bOnZoom = FALSE;
		m_fPrevScale = m_pCoordMgr->m_fScale;
		m_bOnZoom = FALSE;
		if (rectZoom.Width() > 1 && rectZoom.Height() > 1)
			m_pCoordMgr->CalcNewCenterAndScale(rectZoom);

		//CString sStatus;
		//sStatus.Format("배율:%f       ", m_pCoordMgr->m_fScale);
		//CMainFrame* pFrame;
		//pFrame = (CMainFrame*)AfxGetMainWnd();

		//m_pOverlayThread->RePosition();
		//if (m_pDlgOverlayControler->IsWindowVisible() == TRUE)
		//	m_pDlgOverlayControler->UpDateGridDraw();
	
		DrawSituation(TRUE, TRUE, TRUE, TRUE);
	}

    if(localClick)
	{
		m_bMapMove=FALSE;
		ShowLocalFeature(point);
	}
}


BOOL CC4IMapView::OnMouseWheel(UINT, short zDelta, CPoint)
{
    if (!m_pCoordMgr || !m_bDCInitialized || zDelta == 0)
        return FALSE;
    if (zDelta > 0)
        ZoomIn();
    else
        ZoomOut();
    return TRUE;
}

void CC4IMapView::OnMButtonDown(UINT, CPoint point)
{
    m_localOverlay.Cancel();
	mb_moving=FALSE;
	m_bMapMove=FALSE;
    m_rotationStart=point;
	m_rotationStartAngle=DisplayProjection().Angle();
    SetFocus();
	SetCapture();
	m_rotationDragging=true;
}
void CC4IMapView::OnMButtonUp(UINT, CPoint point)
{
    if(!m_rotationDragging)
		return;

    DisplayProjection().SetAngle(m_pCoordMgr,m_rotationStartAngle+(point.x-m_rotationStart.x)*0.5);
    m_rotationDragging=false;
	if(GetCapture()==this)
		ReleaseCapture();
	Invalidate(FALSE);
}

void CC4IMapView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
    if (m_analysis.Finish())
    {
        Invalidate(FALSE);
        return;
    }
	if (m_localOverlay.IsDrawing())
	{
		m_localOverlay.Cancel();
		ReleaseCapture();
		Invalidate(FALSE);
		return;
	}
	m_localClick = point;
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

MOUSE_STATE CC4IMapView::GetMouseState()
{
	return m_pMouseState;
}

void CC4IMapView::SetMouseState(MOUSE_STATE pState)
{

	m_pMouseState = pState;

	// 좌표추출 이벤트 처리 2014-05-09
	if (pState == MOUSE_COORD_INPUT && m_pMouseStateCoordOld != MOUSE_COORD_INPUT)
	{
		m_pMouseStateCoordOld = pState;
#ifdef _DEBUG
		TRACE("[좌표추출 시작]\n");
#endif // _DEBUG
	}
	else
	{
		//if (pState != MOUSE_COORD_INPUT && m_pMouseStateCoordOld == MOUSE_COORD_INPUT)
		//{
		//	if (m_pTracker)
		//	{
		//		m_pTracker->TrackerPointClip();
		//	}
		//	m_pMouseStateCoordOld = pState;

#ifdef _DEBUG
			TRACE("[좌표추출 종료변경]\n");
#endif // _DEBUG
		//}
	}

#ifdef _DEBUG
	TRACE("CURSOR %d\n", m_pMouseState);
#endif

	//if (m_pMeasure != NULL) {

	//	// Measure Draw
	//	ClearMeasureTemp();
	//	if (m_pMeasure->GetCurrentMode() != MEASURE_MODE_NONE)
	//		Invalidate(FALSE);
	//	m_pMeasure->SetCurrentMode(MEASURE_MODE_NONE);
	//	m_bNewCopPanning = FALSE;
	//}

	//m_pSearchOption = SEARCH_NONE;
}

BOOL CC4IMapView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	HINSTANCE hOrgInstance = AfxGetResourceHandle();
	AfxSetResourceHandle(AfxGetInstanceHandle());
	switch (m_pMouseState)
	{
	case MOUSE_DEFAULT:// 기본
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_DEFAULT));
		break;

	case MOUSE_ZOOMIN:// 확대
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_ZOOMIN));
		break;

	case MOUSE_ZOOMOUT:// 축소
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_ZOOMOUT));
		break;
	case MOUSE_PANNING:// 이동
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_PANNING));
		break;
	case MOUSE_ROTATE:// 회전
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_ROTATE));
		break;
	case MOUSE_PRINT: // 인쇄 영역 선택
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_RECT));
		break;

	case MOUSE_SEARCH_POINT: // 속성 조회
		SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_INFO));
		break;

	case MOUSE_SEARCH_CIRCLE: //공간검색 원형
		SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_CIRCLE));
		break;

	case MOUSE_SEARCH_RECTANGLE: //공간검색 사각형
		SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_RECT));
		break;

	case MOUSE_SEARCH:// 지형 검색 (점, 원, 사각형)
	{
		switch (m_pSearchOption)
		{
		case SEARCH_POINT:
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_INFO));
			break;
		case SEARCH_CIRCLE:
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_CIRCLE));
			break;
		case SEARCH_RECT:
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_RECT));
			break;
		case SEARCH_POLYGON:
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_POLYGON));
			break;
		default:
			SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_DEFAULT));
			break;
		}
	}
	break;

	case MOUSE_DISTANCE:// 거리측정
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_LENGTH));
		break;

	case MOUSE_AREA:// 면적측정
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_AREA));
		break;

	case MOUSE_SECTION:// 단면도측정
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_SECTION));
		break;

	case MOUSE_VISIBLE:// 가시권 분석
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_VISIBLE));
		break;

	case MOUSE_RADIUS:// 반경 표시
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_VISIBLE));
		break;
	case MOUSE_SPACEFILTER_CIRCLE:	// 08.22 공간필터 원 중심 설정
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_VISIBLE));
		break;

	case MOUSE_TERRAIN:// 기타 영역 선택 분석
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_TERRAIN));
		break;

	case MOUSE_OVERLAY:// 투명도
		//SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_OVER));
		break;

	case MOUSE_COPLAY://상황도
		//	SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_COP));
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_DEFAULT));
		break;
	case MOUSE_COORD_INPUT:
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_COORD_INPUT));
		break;

	default:
		::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_DEFAULT));
		break;
	}

	AfxSetResourceHandle(hOrgInstance);

#ifdef _DEBUG
	//TRACE("CURSOR %d\n", m_pMouseState);
#endif

	return TRUE;
}