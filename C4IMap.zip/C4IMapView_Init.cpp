#include "pch.h"
#include "C4IMapViewHeader.h"
#include "ViewBitmapBuffers.h"




void CC4IMapView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	
	BeginView();
	//m_pathConfig.SetWork(FILEPATH_CONFIG);

	CRect pClientRect;
	GetClientRect(pClientRect);

	//	Create DCs for Objects
	m_dcMain = new CDC;
	m_dcMainTemp = new CGDCGeo;
	m_dcMapLayer = new CDC;
	m_dcShpLayer = new CDC;
	m_dcDTEDLayer = new CDC;
	m_dcRasterLayer = new CDC;

	m_dcMainTemp->SetCoordMgr(m_pCoordMgr);

	HDC dc = ::GetDC(this->GetSafeHwnd());
	m_dcMain->Attach(dc);

	m_dcMainTemp->CreateCompatibleDC((CGDCGeo*)m_dcMain);
	m_dcMapLayer->CreateCompatibleDC(m_dcMain);
	m_dcMapLayer->SetBkMode(TRANSPARENT);
	m_dcMapLayer->SelectObject(&m_brush_10_10_10);

	m_dcShpLayer->CreateCompatibleDC(m_dcMain);
	m_dcDTEDLayer->CreateCompatibleDC(m_dcMain);
	m_dcRasterLayer->CreateCompatibleDC(m_dcMain);

	InitializeDisplayParameter(pClientRect);
	int nWidth, nHeight;
	nWidth = m_pCoordMgr->m_nDisplayViewWidth;
	nHeight = m_pCoordMgr->m_nDisplayViewHeight;

	m_pBitmap4MainTemp.CreateCompatibleBitmap(m_dcMain, nWidth, nHeight);
	m_pBitmap4Map.CreateCompatibleBitmap(m_dcMain, nWidth, nHeight);
	m_pBitmap4Shape.CreateCompatibleBitmap(m_dcMain, nWidth, nHeight);
	m_pBitmap4DTED.CreateCompatibleBitmap(m_dcMain, nWidth, nHeight);
	m_pBitmap4Raster.CreateCompatibleBitmap(m_dcMain, nWidth, nHeight);


	m_pOldBitmap4MainTemp = ::SelectObject(m_dcMainTemp->GetSafeHdc(), m_pBitmap4MainTemp.GetSafeHandle());
	m_pOldBitmap4Map = ::SelectObject(m_dcMapLayer->GetSafeHdc(), m_pBitmap4Map.GetSafeHandle());
	m_pOldBitmap4Shape = ::SelectObject(m_dcShpLayer->GetSafeHdc(), m_pBitmap4Shape.GetSafeHandle());
	m_pOldBitmap4DTED = ::SelectObject(m_dcDTEDLayer->GetSafeHdc(), m_pBitmap4DTED.GetSafeHandle());
	m_pOldBitmap4Raster = ::SelectObject(m_dcRasterLayer->GetSafeHdc(), m_pBitmap4Raster.GetSafeHandle());

	 
	// �ӽ÷� ���� ����ȣ
	//m_pDlgOverlayControler->InitProjection();
	//m_pDlgOverlayControler->InitSymbolEditTool();
	//m_pDlgOverlayControler->m_piEditTool->OnChangeEditableList();
	//////////////////////////

	// ������ �ʱ�ȭ
	//CCoordMgr* pCoordMgr = GP_COORDMGR;
	//m_pOverlayThread->Initialize(pCoordMgr, LAT_DEGREE, LAT_MIN, LAT_SEC, LNG_DEGREE, LNG_MIN, LNG_SEC, LAT_CHAR, LNG_CHAR);


	m_pCoordMgr->m_fScale = 1.0;
	double x_coordinate, y_coordinate;
	CPoint pPoint;
	m_Coord.degrees_lat_long_to_x_y(38.0, 128.0, &x_coordinate, &y_coordinate);
	m_pCoordMgr->WorldXY2ScreenXY(x_coordinate, y_coordinate, &pPoint.x, &pPoint.y, m_pCoordMgr->m_fCenterX, m_pCoordMgr->m_fCenterY, m_pCoordMgr->m_fScale);
	m_pCoordMgr->SetNewCenter((double)pPoint.x, (double)pPoint.y);

	AfxGetMainWnd()->SetFocus();
	m_bDCInitialized = TRUE;

	BufferDC.CreateCompatibleDC(m_dcMain);
	//bmpBuffer.CreateCompatibleBitmap(m_dcMain, rect.Width(), rect.Height());
	bmpBuffer.CreateCompatibleBitmap(m_dcMain, nWidth, nHeight);
	m_oldBufferBitmap = ::SelectObject(BufferDC.GetSafeHdc(), bmpBuffer.GetSafeHandle());

	// ini ���� ���� ������ �ʿ��ؼ� ��� ����
	//m_pMapConfigMgr = new CMapConfigMgr(this);
	//if(!m_pMapConfigMgr) 
	//	return;    
	//		
	//m_pMapConfigMgr->Init(INIT_FILE);

	//m_pMapConfigMgr->InitMapGroupItem();			//MapGroup, MapGroupList ���� ������ �ε� . ������ �з� 
	//m_pMapConfigMgr->InitDefaultTextPriority();		//DefaultTextPriority ���� �ε�, ��ô�� ��Ʈ ����		
	//m_pMapConfigMgr->InitWorldMapPriority();		//WorldMapPriority ���� �ε�, �������� �Ӽ� ����r
	//m_pMapConfigMgr->InitVectorMapInfo();
	//m_pMapConfigMgr->InitVectorMapProperty();
	//m_pMapConfigMgr->InitMapPriority();
	//m_pMapConfigMgr->OpenRasterMapInfo();			//RasterMapInfo ���� �ε�, CADRG�̹��� ����,����, MBR ,�ӵ� ��ƸԴ� �ֹ� 
	//m_pMapConfigMgr->OpenNameData();				//NameList ���Ϸε�, ���� �ε�ӵ� ��ƸԴ� �ֹ� 		
	//m_pMapConfigMgr->load_shp_attribute(); 	

	//if (m_pMapDataMgr == NULL)
	//	m_pMapDataMgr = new CMapDataMgr(this);
	//else
	//	return;
	
	//if(m_pMapDisplayMgr == NULL)
	//	m_pMapDisplayMgr = new CGMapDisplayMgr(this);
	//if (!m_pMapDisplayMgr) 
	//	return;

	

	
	//LoadShp();
	//mSh.OpenShapeFile();
	//mSh.OpenDTEDFile("d:/mapdata/GDEM-10km-BW.tif");



	CRect rc;
	CGRectGP rect;

	double left, top, right, bottom;

	//CMapViewView *pView=(CMapViewView *)m_pWnd; 
	GetClientRect(&rc);
	//pView->ScreenToClient(&rc);

	m_pCoordMgr->ScreenXY2WorldXY(rc.left, rc.top, &left, &top);
	m_pCoordMgr->ScreenXY2WorldXY(rc.right, rc.bottom, &right, &bottom);
	m_Coord.x_y_to_degrees_lat_long(left, top, &rect.m_R.top, &rect.m_R.left);
	m_Coord.x_y_to_degrees_lat_long(right, bottom, &rect.m_R.bottom, &rect.m_R.right);


	CString leftTop, rightBottom;
	leftTop.Format("%fE%fN", rect.m_R.left, rect.m_R.top);
	rightBottom.Format("%fE%fN", rect.m_R.right, rect.m_R.bottom);

	//m_dted= new CGDtedMgr();
	//m_dted->Create(leftTop, rightBottom, CGDoublePoint(33.0, 33.0), m_dted->m_meterPerSecond.x, m_dted->m_meterPerSecond.y);

	//mHeights = new CAltitude();

}

void CC4IMapView::InitializeDisplayParameter(CRect pClientRect)
{
	m_pCoordMgr->InitDisplayParameter(pClientRect);
}

void CC4IMapView::ReInitializeDCs()
{
    if (!m_bDCInitialized || !BufferDC.GetSafeHdc())
        return;

    CRect client;
    GetClientRect(&client);
    if (client.IsRectEmpty())
        return;

    // A fresh window DC follows the current monitor and client clipping region.
    CClientDC reference(this);
    const std::array<CDC*, 6> contexts = {
        m_dcMainTemp, m_dcMapLayer, m_dcShpLayer,
        m_dcDTEDLayer, m_dcRasterLayer, &BufferDC
    };
    const std::array<CBitmap*, 6> bitmaps = {
        &m_pBitmap4MainTemp, &m_pBitmap4Map, &m_pBitmap4Shape,
        &m_pBitmap4DTED, &m_pBitmap4Raster, &bmpBuffer
    };
    if (!ResizeViewBitmapBuffers(reference, client.Width(), client.Height(),
        contexts, bitmaps))
    {
        TRACE("C4IMap: cannot resize map buffers to %d x %d\n",
            client.Width(), client.Height());
        return;
    }
    m_dcMainTemp->SetCoordMgr(m_pCoordMgr);
}
