#pragma once

#include <afxdockablepane.h>
#include "IndexMapWnd.h"


class CIndexMapViewToolBar : public CMFCToolBar
{
	virtual void OnUpdateCmdUI(CFrameWnd* /*pTarget*/, BOOL bDisableIfNoHndler)
	{
		CMFCToolBar::OnUpdateCmdUI((CFrameWnd*)GetOwner(), bDisableIfNoHndler);
	}

	virtual BOOL AllowShowOnList() const { return FALSE; }
};

class CIndexMapView : public CDockablePane
{
	// �����Դϴ�.
public:
	CIndexMapView();
	virtual ~CIndexMapView();

	void AdjustLayout();
	void OnChangeVisualStyle();


	// Ư���Դϴ�.
protected:
	CIndexMapWnd m_wndIndexMapWnd;					// �ε��� ���� ��
	CIndexMapViewToolBar m_wndIndexMapViewToolBar;	// �ε��� ���� ����

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);

	DECLARE_MESSAGE_MAP()
};

