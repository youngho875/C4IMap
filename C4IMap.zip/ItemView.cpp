#include "pch.h"

#include "MainFrm.h"
#include "ItemView.h"
#include "Resource.h"
#include "C4IMap.h"
#include "C4IMapDoc.h"
#include "C4IMapView.h"



class CItemViewMenuButton : public CMFCToolBarMenuButton
{
	friend class CItemView;

	DECLARE_SERIAL(CItemViewMenuButton)

public:
	CItemViewMenuButton(HMENU hMenu = NULL) : CMFCToolBarMenuButton((UINT)-1, hMenu, -1)
	{
	}

	virtual void OnDraw(CDC* pDC, const CRect& rect, CMFCToolBarImages* pImages, BOOL bHorz = TRUE,
		BOOL bCustomizeMode = FALSE, BOOL bHighlight = FALSE, BOOL bDrawBorder = TRUE, BOOL bGrayDisabledButtons = TRUE)
	{
		pImages = CMFCToolBar::GetImages();

		CAfxDrawState ds;
		pImages->PrepareDrawImage(ds);

		CMFCToolBarMenuButton::OnDraw(pDC, rect, pImages, bHorz, bCustomizeMode, bHighlight, bDrawBorder, bGrayDisabledButtons);

		pImages->EndDrawImage(ds);
	}
};

IMPLEMENT_SERIAL(CItemViewMenuButton, CMFCToolBarMenuButton, 1)

//////////////////////////////////////////////////////////////////////
// ����/�Ҹ�
//////////////////////////////////////////////////////////////////////

CItemView::CItemView()
{
	m_nCurrSort = ID_SORTING_GROUPBYTYPE_COP;
	m_nDrawItemListClickNum = -1;
	m_nlistCtrl_DrawItem_Rs_cursor = -1;
	//m_pMsgBaseList = NULL;
}

CItemView::~CItemView()
{
}

BEGIN_MESSAGE_MAP(CItemView, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_COP_ADD_MEMBER_FUNCTION, OnCOPAddMemberFunction)
	ON_COMMAND(ID_COP_ADD_MEMBER_VARIABLE, OnCOPAddMemberVariable)
	ON_COMMAND(ID_COP_DEFINITION, OnCOPDefinition)
	ON_COMMAND(ID_COP_PROPERTIES, OnCOPProperties)
	ON_COMMAND(ID_NEW_FOLDER_COP, OnNewFolder_COP)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_COMMAND_RANGE(ID_SORTING_GROUPBYTYPE_COP, ID_SORTING_SORTBYACCESS_COP, OnSort)
	ON_UPDATE_COMMAND_UI_RANGE(ID_SORTING_GROUPBYTYPE_COP, ID_SORTING_SORTBYACCESS_COP, OnUpdateSort)

	ON_NOTIFY(NM_CLICK, IDC_COP_LISTCTRL_ITEM, &CItemView::OnNMClickListDrawitem)
	ON_NOTIFY(NM_DBLCLK, IDC_COP_LISTCTRL_ITEM, &CItemView::OnNMDblclkListDrawitem)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_COP_LISTCTRL_ITEM, &CItemView::OnLvnItemchangedListDrawitem)
	ON_NOTIFY(NM_RCLICK, IDC_COP_LISTCTRL_ITEM, &CItemView::OnNMRClickListDrawitem)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_COP_LISTCTRL_ITEM, &CItemView::OnNMCustomdrawListDrawitem)
	ON_NOTIFY(LVN_GETDISPINFO, IDC_COP_LISTCTRL_ITEM, &CItemView::OnLvnGetdispinfoOwnerDrawitem)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClassView �޽��� ó����

int CItemView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// �並 ����ϴ�.
	const DWORD dwViewStyle = WS_CHILD | WS_VISIBLE | TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | TVS_CHECKBOXES | TVS_EX_MULTISELECT;

	if (!m_wndView.Create(dwViewStyle, rectDummy, this, IDC_COP_LISTCTRL_ITEM))
	{
		TRACE0("�׸� �並 ������ ���߽��ϴ�.\n");
		return -1;      // ������ ���߽��ϴ�.
	}

	DWORD dwExStyle = m_wndView.GetExtendedStyle();
	m_wndView.SetExtendedStyle(dwExStyle | LVS_EX_CHECKBOXES | LVS_EX_BORDERSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER | TVS_EX_MULTISELECT | LVS_EX_AUTOSIZECOLUMNS | LVS_OWNERDATA);
	//m_wndView.InsertColumn(IER_DRAWITEM_CHECK_LISTCOL, IER_DRAWITEM_CHECKALL, LVCFMT_LEFT, 25);
	//m_wndView.InsertColumn(IER_DRAWITEM_KEY_LISTCOL, IER_DRAWITEM_KEY, LVCFMT_LEFT, 162);
	//m_wndView.InsertColumn(IER_DRAWITEM_COORD_LISTCOL, IER_DRAWITEM_COORD, LVCFMT_CENTER, 48);
	//m_wndView.InsertColumn(IER_DRAWITEM_IMPORTENT_LISTCOL, _T("�߿�"), LVCFMT_CENTER, 36);
	//m_wndView.InsertColumn(IER_DRAWITEM_ALWAYS_LISTCOL, _T("���"), LVCFMT_CENTER, 36);
	//m_wndView.EnableGroupView(TRUE);
	m_wndView.ModifyStyle(LVS_TYPEMASK, LVS_REPORT);

	// Owner 
	ListView_SetItemCount(m_wndView, 100000);

	// �̹����� �ε��մϴ�.
	m_wndCOPToolBar.Create(this, AFX_DEFAULT_TOOLBAR_STYLE, IDR_SORT_COP);
	m_wndCOPToolBar.LoadToolBar(IDR_SORT_COP, 0, 0, TRUE /* ��� */);

	OnChangeVisualStyle();

	m_wndCOPToolBar.SetPaneStyle(m_wndCOPToolBar.GetPaneStyle() | CBRS_TOOLTIPS | CBRS_FLYBY);
	m_wndCOPToolBar.SetPaneStyle(m_wndCOPToolBar.GetPaneStyle() & ~(CBRS_GRIPPER | CBRS_SIZE_DYNAMIC | CBRS_BORDER_TOP | CBRS_BORDER_BOTTOM | CBRS_BORDER_LEFT | CBRS_BORDER_RIGHT));

	m_wndCOPToolBar.SetOwner(this);

	// ��� ������ �θ� �������� �ƴ� �� ��Ʈ���� ���� ����õ˴ϴ�.
	m_wndCOPToolBar.SetRouteCommandsViaFrame(FALSE);

	CMenu menuSort;
	menuSort.LoadMenu(IDR_POPUP_SORT_COP);

	m_wndCOPToolBar.ReplaceButton(ID_SORT_MENU_COP, CItemViewMenuButton(menuSort.GetSubMenu(0)->GetSafeHmenu()));

	CItemViewMenuButton* pButton = DYNAMIC_DOWNCAST(CItemViewMenuButton, m_wndCOPToolBar.GetButton(0));

	if (pButton != NULL)
	{
		pButton->m_bText = FALSE;
		pButton->m_bImage = TRUE;
		pButton->SetImage(GetCmdMgr()->GetCmdImage(m_nCurrSort));
		pButton->SetMessageWnd(this);
	}

	// ���� Ʈ�� �� �����͸� ���� �ڵ�� ä��ϴ�.
	FillClassView();
#ifdef _DEBUG
	TRACE("[CREATE VIEW] CItemView OnCreate\n");
#endif // _DEBUG
	return 0;
}

void CItemView::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	AdjustLayout();
}

void CItemView::FillClassView()
{

}

void CItemView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	CListCtrl* pWndList = (CListCtrl*)&m_wndView;
	ASSERT_VALID(pWndList);

	if (pWnd != pWndList)
	{
		CDockablePane::OnContextMenu(pWnd, point);
		return;
	}

	if (point != CPoint(-1, -1))
	{
		// Ŭ���� �׸��� �����մϴ�.
		CPoint ptList = point;
		pWndList->ScreenToClient(&ptList);

		UINT flags = 0;
		int nHit = pWndList->HitTest(ptList, &flags);
		if (nHit != -1)
		{
			pWndList->SetHotItem(nHit);
		}
	}

	pWndList->SetFocus();
	CMenu menu;
	if (menu.LoadMenu(IDR_POPUP_SORT_COP))
	{
		CMenu* pSumMenu = menu.GetSubMenu(0);

		if (AfxGetMainWnd()->IsKindOf(RUNTIME_CLASS(CFrameWndEx)))
		{
			CMFCPopupMenu* pPopupMenu = new CMFCPopupMenu;

			if (!pPopupMenu->Create(this, point.x, point.y, (HMENU)pSumMenu->m_hMenu, FALSE, TRUE))
				return;

			((CFrameWndEx*)AfxGetMainWnd())->OnShowPopupMenu(pPopupMenu);
			UpdateDialogControls(this, FALSE);
		}
	}
}

void CItemView::AdjustLayout()
{
	if (GetSafeHwnd() == NULL)
	{
		return;
	}

	CRect rectClient;
	GetClientRect(rectClient);

	int cyTlb = m_wndCOPToolBar.CalcFixedLayout(FALSE, TRUE).cy;

	m_wndCOPToolBar.SetWindowPos(NULL, rectClient.left, rectClient.top, rectClient.Width(), cyTlb, SWP_NOACTIVATE | SWP_NOZORDER);
	m_wndView.SetWindowPos(NULL, rectClient.left + 1, rectClient.top + cyTlb + 1, rectClient.Width() - 2, rectClient.Height() - cyTlb - 2, SWP_NOACTIVATE | SWP_NOZORDER);

}

BOOL CItemView::PreTranslateMessage(MSG* pMsg)
{
	return CDockablePane::PreTranslateMessage(pMsg);
}

void CItemView::OnSort(UINT id)
{
	if (m_nCurrSort == id)
	{
		return;
	}

	m_nCurrSort = id;

	CItemViewMenuButton* pButton = DYNAMIC_DOWNCAST(CItemViewMenuButton, m_wndCOPToolBar.GetButton(0));

	if (pButton != NULL)
	{
		pButton->SetImage(GetCmdMgr()->GetCmdImage(id));
		m_wndCOPToolBar.Invalidate();
		m_wndCOPToolBar.UpdateWindow();
	}
}

void CItemView::OnUpdateSort(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(pCmdUI->m_nID == m_nCurrSort);
}

void CItemView::OnCOPAddMemberFunction()
{
	AfxMessageBox(_T("��� �Լ� �߰�..."));
}

void CItemView::OnCOPAddMemberVariable()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
}

void CItemView::OnCOPDefinition()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
}

void CItemView::OnCOPProperties()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
}

void CItemView::OnNewFolder_COP()
{
	AfxMessageBox(_T("�� ����..."));
}

void CItemView::OnPaint()
{
	CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.

	CRect rectList;
	m_wndView.GetWindowRect(rectList);
	ScreenToClient(rectList);

	rectList.InflateRect(1, 1);
	dc.Draw3dRect(rectList, ::GetSysColor(COLOR_3DSHADOW), ::GetSysColor(COLOR_3DSHADOW));
}

void CItemView::OnSetFocus(CWnd* pOldWnd)
{
	CDockablePane::OnSetFocus(pOldWnd);

	m_wndView.SetFocus();
}

void CItemView::OnChangeVisualStyle()
{
	m_COPViewImages.DeleteImageList();

	UINT uiBmpId = theApp.m_bHiColorIcons ? IDB_COP_VIEW_24 : IDB_COP_VIEW;

	CBitmap bmp;
	if (!bmp.LoadBitmap(uiBmpId))
	{
		TRACE(_T("��Ʈ���� �ε��� �� �����ϴ�. %x\n"), uiBmpId);
		ASSERT(FALSE);
		return;
	}

	BITMAP bmpObj;
	bmp.GetBitmap(&bmpObj);

	UINT nFlags = ILC_MASK;

	nFlags |= (theApp.m_bHiColorIcons) ? ILC_COLOR24 : ILC_COLOR4;

	m_COPViewImages.Create(16, bmpObj.bmHeight, nFlags, 0, 0);
	m_COPViewImages.Add(&bmp, RGB(255, 0, 0));

	m_wndView.SetImageList(&m_COPViewImages, TVSIL_NORMAL);

	m_wndCOPToolBar.CleanUpLockedImages();
	m_wndCOPToolBar.LoadBitmap(theApp.m_bHiColorIcons ? IDB_SORT_COP_24 : IDR_SORT_COP, 0, 0, TRUE /* ��� */);
}

CListCtrl* CItemView::GetView()
{
	return &m_wndView;
}

//void CItemView::SetMsgMgr(CMapXMsgProcBase_List* pMsgBaseList)
//{
//	m_pMsgBaseList = pMsgBaseList;
//}


void CItemView::OnNMClickListDrawitem(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	//if (m_pMsgBaseList)
	//{
	//	m_pMsgBaseList->windowProc(IER_LIST_LCLICK, (LPARAM)pNMHDR, (WPARAM)pResult);
	//	m_pMsgBaseList->copDrawItemFocusContinue(-1, FALSE);
	//	m_pMsgBaseList->copDrawItemKeySearchContinueInListCtrl();
	//}
	m_nDrawItemListClickNum = pNMItemActivate->iItem;
	m_wndView.SetItemState(pNMItemActivate->iItem, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
	*pResult = 0;
}

void CItemView::OnNMDblclkListDrawitem(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	//if (m_pMsgBaseList)
	//{
	//	m_pMsgBaseList->windowProc(IER_LIST_LDCLICK, (LPARAM)pNMHDR, (WPARAM)pResult);

	//	//���ÿ�Ҽ��ý� ȭ���̵��� ���� �ε����ʰ���(14-04-03) 
	//	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	//	if (pFrame)
	//	{
	//		CC4IMapView* pView = (CC4IMapView*)pFrame->GetActiveView();
	//		if (pView)
	//		{
	//			pView->SendMessage(WM_USERLAYERLIST_UPDATEINDEX);
	//		}
	//	}
	//}
	msgBaseListPatrol(FALSE);
	ResetDrawItemFind();
	m_nlistCtrl_DrawItem_Rs_cursor = -1;
	m_nDrawItemListClickNum = -1;

	*pResult = 0;
}

// ����Ʈ ��Ʈ�� Insert �ӵ� ������.. ����Ʈ��Ʈ�� �Ӽ� : owner True  �� ����
void CItemView::OnLvnGetdispinfoOwnerDrawitem(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMLVDISPINFO* pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.   

	// ����� �׳� ����
	*pResult = 0;
	return;

/*
	if (pDispInfo->item.mask & LVIF_TEXT)
	{

		if (m_pMsgBaseList)
			m_pMsgBaseList->CopDrawItemOwnerSync(pDispInfo);

#ifdef _DEBUG
		TRACE("Owner insert [%d][%d][%d][%s]\n", pDispInfo->item.iItem, pDispInfo->item.iSubItem, (int)pDispInfo->item.lParam, pDispInfo->item.pszText);
#endif // _DEBUG
	}
	else if (pDispInfo->item.mask & LVIF_IMAGE)
	{

		if (m_pMsgBaseList)
			m_pMsgBaseList->CopDrawItemOwnerSync(pDispInfo);
	}
*/
	/*else if(pDispInfo->item.mask & LVIF_GROUPID)
	{
		pDispInfo->item.mask |= LVIF_GROUPID;
		pDispInfo->item.stateMask = LVIF_GROUPID;
		if(m_pMsgBaseList)
			m_pMsgBaseList->CopDrawItemOwnerSync(pDispInfo);
	}*/


	*pResult = 0;
}

void CItemView::OnLvnItemchangedListDrawitem(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
/*
	if (m_pMsgBaseList)
	{
		m_pMsgBaseList->windowProc(IER_LIST_SELCHANDED, (LPARAM)pNMHDR, (WPARAM)pResult);


		UINT nOldCheck = pNMLV->uOldState & LVIS_STATEIMAGEMASK;
		UINT nNewCheck = pNMLV->uNewState & LVIS_STATEIMAGEMASK;

		// check ��ư �������� Ȯ��
		if (nOldCheck && nNewCheck && nOldCheck != nNewCheck)
		{
			//m_pParent->SendMessage(WM_3DMAP_UPDATE, 0, 0);
		}
	}
*/
	*pResult = 0;
}


void CItemView::OnNMRClickListDrawitem(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�. 
	//if (m_pMsgBaseList)
	//	m_pMsgBaseList->windowProc(IER_LIST_RCLICK, (LPARAM)pNMHDR, (WPARAM)pResult);

	//m_nDrawItemListClickNum = -1;

	*pResult = 0;
}
void CItemView::OnNMCustomdrawListDrawitem(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	*pResult = 0;

	//if (m_pMsgBaseList)
	//	m_pMsgBaseList->windowProc(IER_LIST_CUSTOMDRAW, (LPARAM)(NMHDR*)pNMHDR, (WPARAM)(LRESULT*)pResult);
}

void CItemView::msgBaseListPatrol(BOOL bPatrol)
{
/*
	if (m_pMsgBaseList)
	{
		CString strButtonNm;
		//GetDlgItemText(IDC_BTN_DRAWITEM_IMPO_PATRAL, strButtonNm); 
		if (bPatrol)
		{
			if (strButtonNm.CompareNoCase(_T("�߿亸��")) == 0)
				if (m_pMsgBaseList->copDrawItemImportentPatrol(TRUE))
				{
					//SetDlgItemText(IDC_BTN_DRAWITEM_IMPO_PATRAL, _T("��ȸ��"));
				}
		}
		else
		{
			if (strButtonNm.CompareNoCase(_T("��ȸ��")) == 0)
				if (!m_pMsgBaseList->copDrawItemImportentPatrol(FALSE))
				{
					//SetDlgItemText(IDC_BTN_DRAWITEM_IMPO_PATRAL, _T("�߿亸��"));
				}
		}
	}
*/
}

void CItemView::ResetDrawItemFind()
{
	//SetDlgItemText(IDC_EDIT_DRAWITEM, _T(""));
	//RefreshSearchCount(0);
	if (m_nlistCtrl_DrawItem_Rs_cursor != -1)
	{
		m_wndView.SetItemState(-1, 0, LVIS_FOCUSED | LVIS_SELECTED);
		m_nlistCtrl_DrawItem_Rs_cursor = -1;
	}
}