#pragma once

#include "../inc/define_struct.h"

typedef enum SEARCHLIST_KIND
{
	SEARCHLIST_NONE = 0, // ��� ����
	SEARCHLIST_SCREEN,	 // ���� �˻� ���
	SEARCHLIST_NAME,	 // �˻��� �˻� ���
	SEARCHLIST_COP_IMPORTANT,	// ��Ȳ�� �߿䵵�ÿ��
	SEARCHLIST_COP_ALWAYS,	// ��Ȳ�� ��ý������
	SEARCHLIST_COP,			// ��Ȳ�� �˻� ���
} SEARCHLIST_KIND;

// COutputSearchList

class COutputSearchList : public CMFCListCtrl
{
	DECLARE_DYNAMIC(COutputSearchList)

public:
	COutputSearchList();
	virtual ~COutputSearchList();

public:
	SEARCHLIST_KIND m_emListType;

	void ClearSearch();
	void SetSearchScreen(CString strCategory, CString strLayer, std::vector<MAPSEARCH_LAYER_RESULT>& vResult);
	void SetSearchName(CString strLayer,std::vector<MAPSEARCH_LAYER_RESULT>& vResult);
	void SetSearchCOP(CString strLayer, std::vector<MAPSEARCH_LAYER_RESULT>& vResult, SEARCHLIST_KIND emListType);

private:
	int m_nColumnCount;
	CMapStringToString m_mapListColumn;
	std::vector<MAPSEARCH_LAYER_RESULT> m_vResult;
	CString m_strTitle;

	void SetSearchResult(std::vector<MAPSEARCH_LAYER_RESULT>& vResult);


protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);

	afx_msg void OnResultCopy();
	afx_msg void OnUpdateResultCopy(CCmdUI* pCmdUI);
	afx_msg void OnResultMove();
	afx_msg void OnUpdateResultMove(CCmdUI* pCmdUI);
	afx_msg void OnNMClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
};
