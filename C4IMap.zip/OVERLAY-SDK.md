# Overlay 독립 빌드 및 SDK 사용

## 빌드 순서

1. `D:\work\상황도\LibSrc\Overlay\Overlay.sln`을 엽니다.
2. `x64 / Release` 또는 `x64 / Debug`로 Overlay를 빌드합니다.
3. 빌드 성공 후 공개 헤더·LIB·DLL이 LibSDK에 자동 복사됩니다.
4. C4IMap을 빌드합니다. C4IMap은 Overlay 프로젝트를 다시 빌드하지 않고 SDK만 사용합니다.

출력 위치:

```text
LibSrc\Overlay\bin\x64\Release\C4Overlay.dll
LibSrc\Overlay\bin\x64\Release\C4Overlay.lib

LibSDK\include\Overlay\*.h
LibSDK\lib\x64\Release\C4Overlay.lib
LibSDK\bin\x64\Release\C4Overlay.dll
```

Debug는 위 경로에서 Release 대신 Debug를 사용합니다.
공개 헤더의 종속 헤더인 Useful.h도 함께 복사합니다. pch.h, framework.h 및 DLL 내부 앱 헤더는 공개 SDK에서 제외합니다.
C4IMap 소스에서는 `#include "Overlay/ObjectLine.h"`처럼 사용합니다.

## 경로 변경

공통 설정: `D:\work\상황도\BuildPaths.props`

```xml
<SdkRoot Condition="'$(SdkRoot)'==''">$(MSBuildThisFileDirectory)LibSDK</SdkRoot>
```

SDK를 다른 위치로 옮기면 이 SdkRoot를 변경합니다.
Overlay의 GeoSdkPaths.props와 C4IMap의 OverlaySdkPaths.props는 공통 설정을 가져오는 연결 파일입니다.
지도 데이터의 실행용 경로 설정인 c4imap-paths.xml과는 용도가 다릅니다.

## 배포

C4IMap 빌드 시 해당 구성의 C4Overlay.dll이 실행 파일 폴더로 자동 복사됩니다.
소스 없이 C4IMap을 빌드하려면 LibSDK의 include와 lib가 필요하고, 실행하려면 DLL도 필요합니다.
Overlay 소스나 API를 변경했을 때는 Overlay를 먼저 빌드하여 SDK를 갱신하고 C4IMap을 빌드하세요.

기존 c4imap\OverlaySDK는 D:\work\overlay-separate의 백업 폴더에 보존되어 있으며, 현재 빌드에서는 참조하지 않습니다.
