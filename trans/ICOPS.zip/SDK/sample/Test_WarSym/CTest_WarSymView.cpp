////////////////////////////////////////////////////////////////////////////////
//
// �� ���α׷� �ҽ��� ���� ��� �Ǹ��� (��)�������ַ�ǿ� �ֽ��ϴ�.
// Copyright (C) C&G Solution, Inc. All rights reserved.
//
// �� ���α׷� �ҽ��� '�����ȣ ���� ǥ�� ������Ʈ ����� ���� SDK'
// (���� 'SDK')�� ���Ե��� ���� ��� (��)�������ַ���� ���� ���ξ��� ���Ƿ�
// ����/����/����/������ �� �����ϴ�.
//
// �� ���α׷� �ҽ��� SDK�� ���Ե� ��� SDK�� �Ϻημ� ����/������ �����ϳ�,
// ���� ���Ϸ� ������ �� ������ SDK ���·� �����ؾ� �մϴ�.
//
// SDK�� ���Ե� ���α׷� �ҽ��� SDK�� ����Ͽ� �����ϴ� �������α׷��� ��������
// ���� �����ϴ� ���̸� �뵵 �̿��� �������� ����� �� �����ϴ�.
//
// ����������Ż�ɺθ� ���Ͽ� �����ϴ� SDK�� �ѱ����� ����� �������� ü�踦
// �����ϱ� ���� ������ �����ϴ� ��� ������ ���������� ���߿� ���Ͽ� ���� ��
// ����� �����մϴ�.
//
// ���/�������/������ SDK�� ����Ͽ� ��ǰ�� �����ϰų� ���� �Ǵ� �н��ϰ���
// �ϴ� ��� ������ (��)�������ַ�ǰ� �����ؾ� �մϴ�.
//
// �ѱ����� ����� ���� ü�� ������ ���� ������ ������ ��� ������ �����̶�
// ����� ��ǰ ���߿� SDK�� ����� ��� ������ (��)�������ַ�ǰ� �����ؾ� �ϸ�
// (��)�������ַ���� SDK �� �������� ���Ḧ û���� �� �ֽ��ϴ�.
// 
//
// �ۼ��� : (��)�������ַ�� ��â��, H.P: 010-2352-1487, E-mail: cgyim@korea.com
// �ۼ��� : 2010/08/15
//
////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Test_WarSym.h"
#include "Test_WarSymRes.h"
#include "CTest_WarSymMainFrame.h"
#include "CTest_WarSymDoc.h"
#include "CTest_WarSymView.h"
#include "ICOPS_Framework/ICOPS_struct.h"
#include "ICOPS_Framework/CTypedBuffer.h"
#include "ICOPS_Framework/CGeometricUtil.h"
#include "ICOPS_WarSym/CwsColorset.h"
#include "ICOPS_WarSym/CwsModifier.h"
#include "ICOPS_WarSym/CwsUtil.h"
#include "ICOPS_WarSym/IWarSymbol.h"
#include "ICOPS_WarSym/IWarSymView.h"
#include "ICOPS_WarSym/IWarSymEditable.h"
#include "ICOPS_WarSym/IWarSymEditOwner.h"
#include "ICOPS_WarSym/IWarSymFactory.h"
#include "ICOPS_WarSym/IWarSymPropertyEditor.h"
#include "ICOPS_LogManager/CLog.h"
#include <math.h>
#include <sys/types.h>
#include <sys/timeb.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

IMPLEMENT_DYNCREATE(CTest_WarSymView, CScrollView)

BEGIN_MESSAGE_MAP(CTest_WarSymView, CScrollView)
	ON_COMMAND(ID_WS_SELECT, CTest_WarSymView::OnSelectSymbol)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_KEYDOWN()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_SETCURSOR()
	ON_COMMAND(ID_EDIT_COPY, CTest_WarSymView::OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, CTest_WarSymView::OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, CTest_WarSymView::OnEditPaste)
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_DRAWMODE_BG, CTest_WarSymView::OnDrawmodeBg)
	ON_UPDATE_COMMAND_UI(ID_DRAWMODE_BG, CTest_WarSymView::OnUpdateDrawmodeBg)
	ON_COMMAND(ID_DRAWMODE_COLOR, CTest_WarSymView::OnDrawmodeColor)
	ON_UPDATE_COMMAND_UI(ID_DRAWMODE_COLOR, CTest_WarSymView::OnUpdateDrawmodeColor)
	ON_COMMAND(ID_DRAWMODE_FILL_FRAME, CTest_WarSymView::OnDrawmodeFillFrame)
	ON_UPDATE_COMMAND_UI(ID_DRAWMODE_FILL_FRAME, CTest_WarSymView::OnUpdateDrawmodeFillFrame)
	ON_COMMAND(ID_DRAWMODE_SHOW_FRAME, CTest_WarSymView::OnDrawmodeShowFrame)
	ON_UPDATE_COMMAND_UI(ID_DRAWMODE_SHOW_FRAME, CTest_WarSymView::OnUpdateDrawmodeShowFrame)
	ON_COMMAND(ID_DRAWMODE_SHOW_ICON, CTest_WarSymView::OnDrawmodeShowIcon)
	ON_UPDATE_COMMAND_UI(ID_DRAWMODE_SHOW_ICON, CTest_WarSymView::OnUpdateDrawmodeShowIcon)
	ON_COMMAND(ID_LUMINO_DARK, CTest_WarSymView::OnLuminoDark)
	ON_UPDATE_COMMAND_UI(ID_LUMINO_DARK, CTest_WarSymView::OnUpdateLuminoDark)
	ON_COMMAND(ID_LUMINO_MEDIUM, CTest_WarSymView::OnLuminoMedium)
	ON_UPDATE_COMMAND_UI(ID_LUMINO_MEDIUM, CTest_WarSymView::OnUpdateLuminoMedium)
	ON_COMMAND(ID_LUMINO_LIGHT, CTest_WarSymView::OnLuminoLight)
	ON_UPDATE_COMMAND_UI(ID_LUMINO_LIGHT, CTest_WarSymView::OnUpdateLuminoLight)
	ON_COMMAND(ID_LUMINO_CUSTOM, CTest_WarSymView::OnLuminoCustom)
	ON_UPDATE_COMMAND_UI(ID_LUMINO_CUSTOM, CTest_WarSymView::OnUpdateLuminoCustom)
	ON_COMMAND(ID_TEST_SPEED, CTest_WarSymView::OnTestSpeed)
	ON_COMMAND(ID_TEST_CLEAR, CTest_WarSymView::OnTestClear)
	ON_COMMAND(ID_EDIT_DELETE, CTest_WarSymView::OnEditDelete)
	ON_COMMAND(ID_EDIT_PROPERTY, CTest_WarSymView::OnEditProperty)
	ON_COMMAND(ID_EDIT_PAIRING_ADD, CTest_WarSymView::OnPairingAdd)
	ON_COMMAND(ID_EDIT_PAIRING_RESET, CTest_WarSymView::OnPairingReset)
	ON_COMMAND(ID_TEST_CACHE_SYMIMG, CTest_WarSymView::OnCacheSymimg)
	ON_UPDATE_COMMAND_UI(ID_TEST_CACHE_SYMIMG, CTest_WarSymView::OnUpdateCacheSymimg)
	ON_COMMAND(ID_WS_COPY, CTest_WarSymView::OnCopySelected)
	ON_UPDATE_COMMAND_UI(ID_WS_COPY, CTest_WarSymView::OnUpdateCopySelected)
	ON_COMMAND(ID_EDIT_REFRESH_MODE, CTest_WarSymView::OnEditRefreshMode)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REFRESH_MODE, CTest_WarSymView::OnUpdateRefreshMode)
	ON_COMMAND(ID_EDIT_INVERSE_MODE, CTest_WarSymView::OnInverseMode)
	ON_UPDATE_COMMAND_UI(ID_EDIT_INVERSE_MODE, CTest_WarSymView::OnUpdateInverseMode)
	ON_COMMAND(ID_USE_COMMON_LANG, CTest_WarSymView::OnUseCommonLang)
	ON_UPDATE_COMMAND_UI(ID_USE_COMMON_LANG, CTest_WarSymView::OnUpdateUseCommonLang)
	ON_COMMAND(ID_DEBUG_PATTERN_LINE, CTest_WarSymView::OnDebugPatternLine)
	ON_COMMAND(ID_DEBUG_MEM_LEAK, CTest_WarSymView::OnDebugMemLeak)
	ON_COMMAND_RANGE(ID_TGLABEL_START, ID_TGLABEL_END, CTest_WarSymView::OnToggleTgLabel)
	ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()

CTest_WarSymView::CTest_WarSymView()
{
	m_pBgImg = NULL;
	m_piMapProj = NULL;
	m_piEditTool = NULL;
	m_pDoubleBuffer = NULL;
	m_strLastSymCode.Empty();
	m_nTestMode = CTest_WarSymView::None;
	m_bCacheSymImg = FALSE;
	mTestPtnIcon = NULL;
	mTgLabelTarget = NULL;

	mMemLeakTimer = 0;
	mMemLeakTestOffset.X = 0.0f;
	mMemLeakTestOffset.Y = 0.0f;
	mMemLeakTestOffsetDir.Width = 1.0f;
	mMemLeakTestOffsetDir.Height = 1.0f;

	m_pEditOwner = new CTest_WarSymViewEditOwner(this);
}


CTest_WarSymView::~CTest_WarSymView()
{
	ClearTestData();
	if (m_pBgImg!=NULL) delete m_pBgImg;
	if (m_piEditTool!=NULL) m_piEditTool->Release();
	if (m_piMapProj!=NULL) m_piMapProj->Release();
	if (m_pDoubleBuffer!=NULL) delete m_pDoubleBuffer;
	if (m_pEditOwner!=NULL) delete m_pEditOwner;

	if (mTestPtnIcon!=NULL) {
		delete mTestPtnIcon;
		mTestPtnIcon = NULL;
	}
}


//////////////////////////////////////////////////////////////////////////////////
//// IcopsUnknown implementation
//
//BOOL CTest_WarSymView::QueryInterface(const CString &ifName, void **ppv)
//{
//	if (ifName==_T("IcopsUnknown"))
//	{
//		*ppv = dynamic_cast<IcopsUnknown *>(this);
//		AddRef();
//		return TRUE;
//	}
//	if (ifName==_T("IWarSymEditOwner"))
//	{
//		*ppv = dynamic_cast<IWarSymEditOwner *>(this);
//		AddRef();
//		return TRUE;
//	}
//
//	return FALSE;
//}


////////////////////////////////////////////////////////////////////////////////
// IWarSymEditOwner implementation

void CTest_WarSymView::GetEditables(ICOPS::CPtrArrayIWarSymEditable &ret)
{
	BOOL		bRes;
	INT_PTR		inx, count;
	CTest_OverItem	**ppItems;
	ICOPS::IWarSymEditablePtr	piEditable;
	CTest_WarSymDoc	*pDoc = GetDocument();

	count = pDoc->m_parOverItems.GetSize();
	if (count<=0) return;

	ppItems = (CTest_OverItem **) pDoc->m_parOverItems.GetData();
	for (inx=0; inx<count; inx++)
	{
		piEditable = NULL;
		bRes = ppItems[inx]->QueryInterface(_T("IWarSymEditable"), (void **) &piEditable);
		if (bRes)
		{
			ret.Add(piEditable);
		}
	}
}


void CTest_WarSymView::AddEditable(ICOPS::IWarSymEditable *piEditable, BOOL bCompleted)
{
	//CTest_OverItem		*pItem;
	//CTest_WarSymDoc	*pDoc = GetDocument();
	//ICOPS::IWarSymbol	*piSym;
	//INT_PTR		count;
	//BOOL		bRes;
	//
	//bRes = piEditable->QueryInterface(_T("IWarSymbol"), (void **) &piSym);
	//if (bRes)
	//{
	//	count = m_piEditTool->GetCoordinateCount();
	//	if (count>0)
	//	{
	//		pItem = new CTest_OverItem;
	//		pItem->m_piSym = piSym;
	//		pItem->m_Points.SetCount(count);
	//		m_piEditTool->GetCoordinates(pItem->m_Points.GetBuffer(), count);
	//		pItem->m_piSym->ApplyDrawMode(&m_sDrawMode);
	//		pDoc->m_parOverItems.Add(pItem);
	//		pItem->AddRef();

	//		m_piEditTool->OnChangeEditableList();
	//	}
	//	else
	//	{
	//		piSym->Release();
	//	}
	//}

	CTest_OverItemPtr	pItem;
	CTest_WarSymDoc		*pDoc = GetDocument();
	INT_PTR		count;
	BOOL		bRes;

	pItem = NULL;
	bRes = piEditable->QueryInterface(_T("CTest_OverItem"), (void **) &pItem);

	if (bRes && pItem!=NULL)
	{
		count = m_piEditTool->GetCoordinateCount();
		if (count>0)
		{
			if (pItem->m_piSym!=NULL) pItem->m_piSym->CacheSymbolImage(m_bCacheSymImg);
			pDoc->m_parOverItems.Add(pItem);
			pDoc->SetModifiedFlag(TRUE);
			pItem->AddRef();

			m_piEditTool->OnChangeEditableList();
		}
	}

	if (piEditable!=NULL)  piEditable->Release();
}


void CTest_WarSymView::DeleteEditable(IWarSymEditable *piEditable)
{
	BOOL		bRes;
	INT_PTR		inx, count;
	CTest_OverItem		*pDel;
	CTest_OverItem		*pItem;
	CTest_WarSymDoc		*pDoc = GetDocument();

	ASSERT(piEditable!=NULL);
	if (piEditable==NULL) return;

	pDel = NULL;
	bRes = piEditable->QueryInterface(_T("CTest_OverItem"), (void **) &pDel);
	if (!bRes || pDel==NULL)
	{
		ASSERT(FALSE);
		return;
	}

	count = pDoc->m_parOverItems.GetSize();
	for (inx=0; inx<count; inx++)
	{
		pItem = pDoc->m_parOverItems.GetAt(inx);
		if (pItem==pDel)
		{
			pDoc->m_parOverItems.RemoveAt(inx);
			pDoc->SetModifiedFlag(TRUE);
			pDel->Release();
			pItem->Release();
			return;
		}
	}
	pDel->Release();
}


void CTest_WarSymView::DoContextMenu(Gdiplus::Graphics *pGrpx, UINT nFlags, const CPoint &point, CPtrArrayIWarSymEditable *pSelected)
{
	mTgLabelTarget = NULL;

	BOOL	bRes;
	CMenu	menu;
	CMenu	*pSubMenu = NULL;
	CPoint	ptPop;

	bRes = FALSE;
	if (pSelected->GetSize()>0) {
		bRes = menu.LoadMenu(IDR_MENU_POP);
	}
#ifdef _DEBUG
	else {
		bRes = menu.LoadMenu(IDR_MENU_POP_DEBUG);
	}
#endif

	if (!bRes) {
		return;	// �޴� ���� ����
	}
	pSubMenu = menu.GetSubMenu(0);
	if (pSubMenu==NULL) {
		return;
	}

	// ���̺� ��� �߰�
	if (pSelected->GetSize()==1) {
		MakeTgLableMenu(pSubMenu, pSelected->GetAt(0));
	}

	// ���콺 �޴� ����� Ŀ�� ��ġ ����
	m_ptContext.X = (Gdiplus::REAL) point.x;
	m_ptContext.Y = (Gdiplus::REAL) point.y;

	ptPop = point;
	ClientToScreen(&ptPop);
	pSubMenu->TrackPopupMenu(0, ptPop.x, ptPop.y, this);
}


void CTest_WarSymView::Refresh()
{
	Invalidate();
}


CWnd *CTest_WarSymView::GetWnd()
{
	return (CWnd *) this;
}


////////////////////////////////////////////////////////////////////////////////
// Editor operations

void CTest_WarSymView::LoadBackgroundImage()
{
	CTest_WarSymApp		*pApp = (CTest_WarSymApp *) ::AfxGetApp();
	Gdiplus::Bitmap		*pBmp;
	_bstr_t		bstrPath;

	bstrPath = pApp->GetProfileString(_T("Settings"), _T("bgimg"));
	if (bstrPath.length()<=0) return;

	pBmp = Gdiplus::Bitmap::FromFile(bstrPath);
	if (pBmp->GetLastStatus()!=Gdiplus::Ok) return;

	if (m_pBgImg!=NULL) delete m_pBgImg;
	m_pBgImg = pBmp;
}


void CTest_WarSymView::InitProjection()
{
	CTest_WarSymApp		*pApp = (CTest_WarSymApp *) ::AfxGetApp();
	ICOPS::CAppContext	*pAppCxt = pApp->m_pAppCxt;
	ICOPS::SGeoCoord2	gpC;
	BOOL	bRes;

	bRes = pAppCxt->CreateObject(_T("ICOPS_Framework"), _T(".dll"), _T("CMapProjectionNone"), _T("IMapProjection"), (void **) &m_piMapProj);
	if (!bRes)
	{
		ICOPS::CLog::AddLog(__FILE__, __LINE__, ICOPS::CLog::Log_Error, _T("��ǥ���� ��ä ���� ���� : CMapProjectionNone / IMapProjection"));
		return;
	}

	// ���� �߽���ǥ ����
	gpC.lon = 128.0;
	gpC.lat = 37.0;

	m_piMapProj->SetRadius(EARTH_RADIUS);
	m_piMapProj->SetMapScale(1000000);
	m_piMapProj->SetZoomFactor(1.0f);
	m_piMapProj->SetCenter(&gpC);
}


void CTest_WarSymView::InitSymbolEditTool()
{
	CTest_WarSymApp		*pApp = (CTest_WarSymApp *) ::AfxGetApp();
	ICOPS::CAppContext	*pAppCxt = pApp->m_pAppCxt;
	BOOL	bRes;

	bRes = pAppCxt->CreateObject(_T("IWarSymEditTool"), (void **) &m_piEditTool);
	if (!bRes)
	{
		ICOPS::CLog::AddLog(__FILE__, __LINE__, ICOPS::CLog::Log_Error, _T("IWarSymEditTool �������̽��� �����ϴ� ��������� ��ü ���� ����"));
	}
	else
	{
		m_piMapProj->SetZoomFactor(1.0f);
		m_piMapProj->SetMapScale(1.0f);
		m_rMPW = 1.0f;

		// Initialize IWarSymEditTool component object
		m_piEditTool->SetEditOwner(dynamic_cast<ICOPS::IWarSymEditOwner *>(m_pEditOwner));
		m_piEditTool->SetMapProjection(m_piMapProj);
		m_piEditTool->SetMeterPerPixel(m_rMPW);
		m_piEditTool->SnapToGrid(FALSE);

		m_piEditTool->SetEditingMode(RefreshOnChange);	// ��ȣ �۵��� ��ȣ ����ø��� ȭ�� ����
		//m_piEditTool->SetEditingMode(UseInverseDraw);	// ��ȣ �۵��� ��ȣ ����� ���� ���� ����Ͽ� rubber banding ��� ����
	}
}


void CTest_WarSymView::OnPrepareGraphics(Gdiplus::Graphics *pGrpx, const CRect& rcBounds)
{
	CPoint	cp;
	ICOPS::SOrthoCoord2	vc;

	// reset transform matrix
	pGrpx->ResetTransform();

	cp = rcBounds.CenterPoint();
	vc.x = cp.x;
	vc.y = cp.y;
	m_piMapProj->SetViewOrigin(&vc);
	m_piMapProj->SetViewRect(rcBounds);
}


void CTest_WarSymView::DrawOverItems(Gdiplus::Graphics *pGrpx)
{
	INT_PTR		inx, count, bufSize;
	CTest_OverItem	**ppItems, *pItem;
	CTest_WarSymDoc	*pDoc = GetDocument();
	Gdiplus::PointF		*pWp;
	const ICOPS::SGeoCoord2	*pGp;
	ICOPS::CTypedBuffer<Gdiplus::PointF>	bufWp;
	Gdiplus::Color	clrCtrl(70, 0, 0, 0);

	count = pDoc->m_parOverItems.GetSize();
	if (count<=0) return;

	struct _timeb tmStart;
	struct _timeb tmEnd;
	CString strSpan;

	ppItems = (CTest_OverItem **) pDoc->m_parOverItems.GetData();
	for (inx=0; inx<count; inx++)
	{
		pItem = ppItems[inx];

		bufSize = pItem->GetCoordCount();
		if (bufSize>0)
		{
			pWp = bufWp.SetCount(bufSize);
			pGp = pItem->GetCoordData(m_piMapProj);
			m_piMapProj->Forward(pGp, pWp, bufSize);
			MakeMemLeakTestPoints(pWp, bufSize);

#if _MFC_VER < 0x0800		// for Version .NET 2003
			_ftime(&tmStart);
#else
			_ftime_s(&tmStart);
#endif

			pItem->Draw(pGrpx, pWp, bufSize, m_rMPW);

#if _MFC_VER < 0x0800		// for Version .NET 2003
			_ftime(&tmEnd);
#else
			_ftime_s(&tmEnd);
#endif

			time_t milSec = tmEnd.time - tmStart.time;
			milSec *= 1000;
			milSec -= tmStart.millitm;
			milSec += tmEnd.millitm;
			strSpan.Format(_T("%d ���� �ð� : %.3f\n"), inx, milSec/1000.0f);
			ICOPS::CLog::AddLog(__FILE__, __LINE__, ICOPS::CLog::Log_Debug, (LPCTSTR) strSpan);
		}
	}
}


void CTest_WarSymView::ApplyDrawModeToAll()
{
	INT_PTR		inx, count;
	CTest_OverItem	**ppItems;
	CTest_OverItem	*pItem;
	CTest_WarSymDoc	*pDoc = GetDocument();
	SWarSymDrawMode	*pSymDrawMode;
	ICOPS::IWarSymbolPtr piSym;

	count = pDoc->m_parOverItems.GetSize();
	if (count<=0) return;

	ppItems = (CTest_OverItem **) pDoc->m_parOverItems.GetData();
	for (inx=0; inx<count; inx++)
	{
		pItem = ppItems[inx];
		piSym = pItem->m_piSym;

		pSymDrawMode = piSym->GetDrawMode();

		pSymDrawMode->isBgWhite = m_sDrawMode.isBgWhite;
		pSymDrawMode->isColorMode = m_sDrawMode.isColorMode;
		pSymDrawMode->fillFrame = m_sDrawMode.fillFrame;
		pSymDrawMode->showFrame = m_sDrawMode.showFrame;
		pSymDrawMode->showIcon = m_sDrawMode.showIcon;
		pSymDrawMode->luminance = m_sDrawMode.luminance;
		pSymDrawMode->dispType = m_sDrawMode.dispType;
		pSymDrawMode->civ = m_sDrawMode.civ;
		//pSymDrawMode->symState = m_sDrawMode.symState;
		pSymDrawMode->isFillRate = m_sDrawMode.isFillRate;
		pSymDrawMode->fillRate = m_sDrawMode.fillRate;
		pSymDrawMode->fillRateColor = m_sDrawMode.fillRateColor;

		piSym->InvalidateSymbolImage();
	}
}


Gdiplus::Color CTest_WarSymView::GetBgColor()
{
	if (m_sDrawMode.isBgWhite)
	{
		return Gdiplus::Color(255, 254, 254, 254);
	}
	else
	{
		return Gdiplus::Color(255, 1, 1, 1);
	}
}


void CTest_WarSymView::ZoomIn(BOOL bFitToSelected)
{
	FLOAT	fZoom, fScale;

	fScale = m_piMapProj->GetMapScale();
	fZoom = m_piMapProj->GetZoomFactor();
	fZoom *= 1.2f;	//2.0;
	m_piMapProj->SetZoomFactor(fZoom);
	m_rMPW = fScale / fZoom;
	m_piEditTool->SetMeterPerPixel(m_rMPW);
	Invalidate();
}


void CTest_WarSymView::ZoomOut(BOOL bFitToSelected)
{
	FLOAT	fZoom, fScale;

	fScale = m_piMapProj->GetMapScale();
	fZoom = m_piMapProj->GetZoomFactor();
	fZoom /= 1.2f;	//2.0;
	m_piMapProj->SetZoomFactor(fZoom);
	m_rMPW = fScale / fZoom;
	m_piEditTool->SetMeterPerPixel(m_rMPW);
	Invalidate();
}


void CTest_WarSymView::MoveToSelectedCenter()
{
	Invalidate();
}


void CTest_WarSymView::Pan(int dirX, int dirY)
{
	ICOPS::SOrthoCoord2	vp;
	ICOPS::SGeoCoord2		gp;

	m_piMapProj->GetViewOrigin(&vp);
	vp.x += dirX;
	vp.y += dirY;
	m_piMapProj->Inverse(&vp, &gp, 1);
	m_piMapProj->SetCenter(&gp);
	Invalidate();
}


void CTest_WarSymView::MakeTgLableMenu(CMenu *pMenu, ICOPS::IWarSymEditable *piSymEd) {
	IWarSymbolPtr piSym;
	BOOL res;

	res = piSymEd->QueryInterface(_T("IWarSymbol"), (void **) &piSym);
	if (!res) {
		return;
	}

	ICOPS::IWarSymView *piSymView = piSym->GetSymbolView();
	if (piSymView==NULL) {
		return;
	}

	// ��������ȣ ���̺� ��� ���
	CStringArray straLabels;
	piSymView->EnumLabels(straLabels);
	INT_PTR count = straLabels.GetSize();
	if (count<=0) {
		return;
	}

	CMenu *pSubMenu = new CMenu;
	res = pSubMenu->CreatePopupMenu();
	if (!res) {
		delete pSubMenu;
		return;
	}
	res = pMenu->AppendMenu(MF_POPUP, (UINT_PTR) pSubMenu->GetSafeHmenu(), _T("��������ȣ ���̺�"));
	if (!res) {
		delete pSubMenu;
		return;
	}

	BOOL bShow;
	CString strMenu;
	INT_PTR inx;
	for (inx=0; inx<count; inx++) {
		strMenu = straLabels.GetAt(inx);
		bShow = piSymView->IsShowLabel(strMenu);
		if (bShow) {
			pSubMenu->AppendMenu(MF_STRING | MF_CHECKED, ID_TGLABEL_START + inx, strMenu);
		} else {
			pSubMenu->AppendMenu(MF_STRING, ID_TGLABEL_START + inx, strMenu);
		}
	}

	delete pSubMenu;

	mTgLabelTarget = piSymView;
}


void CTest_WarSymView::OnLButtonDown(UINT nFlags, CPoint point)
{
	CRect		rc;
	CClientDC	dc(this);
	Gdiplus::Graphics	grpx(dc.GetSafeHdc());

	GetClientRect(&rc);
	OnPrepareGraphics(&grpx, rc);

	m_piEditTool->OnLButtonDown(&grpx, nFlags, point);
}


void CTest_WarSymView::OnLButtonUp(UINT nFlags, CPoint point)
{
	CRect		rc;
	CClientDC	dc(this);
	Gdiplus::Graphics	grpx(dc.GetSafeHdc());

	GetClientRect(&rc);
	OnPrepareGraphics(&grpx, rc);

	m_piEditTool->OnLButtonUp(&grpx, nFlags, point);
}


void CTest_WarSymView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	CRect		rc;
	CClientDC	dc(this);
	Gdiplus::Graphics	grpx(dc.GetSafeHdc());

	GetClientRect(&rc);
	OnPrepareGraphics(&grpx, rc);

	m_piEditTool->OnLButtonDblClk(&grpx, nFlags, point);
}


void CTest_WarSymView::OnRButtonDown(UINT nFlags, CPoint point)
{
	CRect		rc;
	CClientDC	dc(this);
	Gdiplus::Graphics	grpx(dc.GetSafeHdc());

	GetClientRect(&rc);
	OnPrepareGraphics(&grpx, rc);

	m_piEditTool->OnRButtonDown(&grpx, nFlags, point);
}


void CTest_WarSymView::OnRButtonUp(UINT nFlags, CPoint point)
{
	CRect		rc;
	CClientDC	dc(this);
	Gdiplus::Graphics	grpx(dc.GetSafeHdc());

	GetClientRect(&rc);
	OnPrepareGraphics(&grpx, rc);

	m_piEditTool->OnRButtonUp(&grpx, nFlags, point);
}


void CTest_WarSymView::OnMouseMove(UINT nFlags, CPoint point)
{
	CRect		rc;
	CClientDC	dc(this);
	Gdiplus::Graphics	grpx(dc.GetSafeHdc());

	GetClientRect(&rc);
	OnPrepareGraphics(&grpx, rc);

	m_piEditTool->OnMouseMove(&grpx, nFlags, point);
}


// Ctrl        : Ȯ��/���
// Ctrl + Alt  : ���õ� ���� �߽����� Ȯ��/���
// Shift       : �����̵�
// Shift + Alt : �¿��̵�
BOOL CTest_WarSymView::OnMouseWheel(UINT nFlags, short zDelta, CPoint point)
{
	BOOL	bAlt;
	SHORT	keyStat;

	keyStat = GetKeyState(VK_LMENU);
	bAlt = (keyStat & 0x8000) != 0;

	if (nFlags & MK_CONTROL)
	{
		if (zDelta<0)
		{	// Ȯ��
			ZoomIn(bAlt);
		}
		else
		{	// ���
			ZoomOut(bAlt);
		}

		return TRUE;
	}
	else if (nFlags & MK_SHIFT)
	{
		if (bAlt)
		{	// �¿��̵�
			Pan((zDelta<0 ? 1 : -1), 0);
		}
		else
		{	// �����̵�
			Pan(0, (zDelta<0 ? -1 : 1));
		}
		return TRUE;
	}

	return CScrollView::OnMouseWheel(nFlags, zDelta, point);
}


void CTest_WarSymView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CRect		rc;
	CClientDC	dc(this);
	Gdiplus::Graphics	grpx(dc.GetSafeHdc());

	GetClientRect(&rc);
	OnPrepareGraphics(&grpx, rc);

	m_piEditTool->OnKeyDown(&grpx, nChar, nRepCnt, nFlags);
}


void CTest_WarSymView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CScrollView::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CTest_WarSymView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CScrollView::OnVScroll(nSBCode, nPos, pScrollBar);
}


void CTest_WarSymView::OnSize(UINT nType, int cx, int cy)
{
	CScrollView::OnSize(nType, cx, cy);

	if (m_pDoubleBuffer!=NULL)
	{
		delete m_pDoubleBuffer;
		m_pDoubleBuffer = NULL;
	}
}


BOOL CTest_WarSymView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	BOOL	bRes;

	bRes = m_piEditTool->OnSetCursor(pWnd, nHitTest, message);

	if (!bRes)
	{
		bRes = CScrollView::OnSetCursor(pWnd, nHitTest, message);
	}

	return bRes;
}


void CTest_WarSymView::OnEditCopy()
{
}


void CTest_WarSymView::OnEditCut()
{
}


void CTest_WarSymView::OnEditPaste()
{
}


////////////////////////////////////////////////////////////////////////////////
// Ooperations


BOOL CTest_WarSymView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

//void Test(Gdiplus::Graphics *pGrpx) {
//	ICOPS::IWarSymFactoryPtr piSymFac;
//
//	CTest_WarSymApp *pApp = (CTest_WarSymApp *) ::AfxGetApp();
//	ICOPS::CAppContext *pAppCxt = pApp->m_pAppCxt;
//
//	BOOL bRes = pAppCxt->GetStockObject(_T("IWarSymFactory"), (void **) &piSymFac);
//	if (!bRes) {
//		ICOPS::CLog::AddLog(__FILE__, __LINE__, ICOPS::CLog::Log_Error, _T("�����ȣ���� ��ü ��� ����"));
//		return;
//	}
//
//	ICOPS::IWarSymbolPtr piSym;
//	CString strCode(_T("G*G*GLB---****X"));
//
//	bRes = piSymFac->CreateSymbol(strCode, &piSym);
//	if (bRes) {
//		Gdiplus::PointF *pts = new Gdiplus::PointF[5];
//		pts[0].X = 100.0f;	pts[0].Y = 100.0f;
//		pts[1].X = 200.0f;	pts[1].Y = 200.0f;
//		pts[2].X = 300.0f;	pts[2].Y = 100.0f;
//		pts[3].X = 400.0f;	pts[3].Y = 200.0f;
//		pts[4].X = 500.0f;	pts[4].Y = 100.0f;
//
//		IWarSymView *pSymView = piSym->GetSymbolView();
//		CwsModifier *pMod = pSymView->GetModifier();
//		pMod->Set(CwsModifier::B, _T("E"));
//		pMod->Set(CwsModifier::T, _T("12"));
//		pMod->Set(CwsModifier::T1, _T("23"));
//		pSymView->LinkModifierInfo();
//
//		piSym->Draw(pGrpx, pts, 5, 1.0);
//		delete[] pts;
//	}
//}


void CTest_WarSymView::OnDraw(CDC *pDC)
{
	HDC hDC = pDC->GetSafeHdc();

	int dpiX = ::GetDeviceCaps(hDC, LOGPIXELSX); // pixels per logical inch
	int dpiY = ::GetDeviceCaps(hDC, LOGPIXELSY); // pixels per logical inch

	// ������Ʈ ������ ����� DPI�� �����Ѵ�.
	// �������� ������ ���� �ʿ�� GetDeviceCaps() �Լ��� ���� �� ����ϰ�
	// ���� ���ʹ� �ֱٿ� ������ ���� ����Ѵ�.
	ICOPS::CGeometricUtil::SetDPI(dpiX, dpiY);

	Gdiplus::Graphics	grpxDC(hDC);
	CRect	rc;

//#if _DEBUG
//	Test(&grpxDC);
//	return;
//#endif

	GetClientRect(&rc);

#if defined(_DEBUG) && defined(new)
#undef new
#endif

	if (m_pDoubleBuffer==NULL)
	{
		m_pDoubleBuffer = new Gdiplus::Bitmap(rc.Width(), rc.Height(), &grpxDC);
	}
	else
	{
		if (m_pDoubleBuffer->GetWidth()<(UINT)rc.Width() || m_pDoubleBuffer->GetHeight()<(UINT)rc.Height())
		{
			delete m_pDoubleBuffer;
			m_pDoubleBuffer = new Gdiplus::Bitmap(rc.Width(), rc.Height(), &grpxDC);
		}
	}

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

	Gdiplus::Graphics	grpx(m_pDoubleBuffer);

	if (m_pBgImg==NULL)
	{
		grpx.Clear(GetBgColor());
	}
	else
	{
		INT		imgW, imgH, clW, clH;
		INT		x, y;

		imgW = m_pBgImg->GetWidth() / 2;
		imgH = m_pBgImg->GetHeight() / 2;
		clW = rc.Width() / 2;
		clH = rc.Height() / 2;
		x = clW - imgW;
		y = clH - imgH;		

		grpx.DrawImage(m_pBgImg, x, y);
	}

	OnPrepareGraphics(&grpx, rc);

	switch (m_nTestMode) {
	case CTest_WarSymView::SpeedTest :
		DrawSpeedTest(&grpx);
		break;

	default :
		// Draw symbols
		DrawOverItems(&grpx);

		// Draw editing item or states
		m_piEditTool->DrawEditingStatus(&grpx);
	}

	// Swap buffers
	grpxDC.DrawImage(m_pDoubleBuffer, rc.left, rc.top, rc.Width(), rc.Height());

	switch (m_nTestMode) {
	case CTest_WarSymView::PatternLineTest :
		DrawPatternLineTest(&grpxDC);
		break;
	case CTest_WarSymView::MemoryLeakTest :
//		DrawMemoryLeakTest(&grpxDC);
		break;
	}
}


void CTest_WarSymView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	LoadBackgroundImage();
	InitProjection();
	InitSymbolEditTool();

	CSize sizeTotal;

	sizeTotal.cx = sizeTotal.cy = 100;
	SetScrollSizes(MM_TEXT, sizeTotal);

	m_piEditTool->OnChangeEditableList();
}


BOOL CTest_WarSymView::OnPreparePrinting(CPrintInfo* pInfo)
{
	return DoPreparePrinting(pInfo);
}


void CTest_WarSymView::OnBeginPrinting(CDC *pDC, CPrintInfo *pInfo)
{
}


void CTest_WarSymView::OnEndPrinting(CDC *pDC, CPrintInfo *pInfo)
{
}


#ifdef _DEBUG
void CTest_WarSymView::AssertValid() const
{
	CScrollView::AssertValid();
}


void CTest_WarSymView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}


CTest_WarSymDoc* CTest_WarSymView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTest_WarSymDoc)));
	return (CTest_WarSymDoc*)m_pDocument;
}
#endif //_DEBUG


void CTest_WarSymView::OnSelectSymbol()
{
	BOOL	bRes;
	CTest_OverItem			*pItem;
	CTest_WarSymApp			*pApp = (CTest_WarSymApp *) ::AfxGetApp();
	ICOPS::CAppContext		*pAppCxt = pApp->m_pAppCxt;
	ICOPS::IWarSymFactoryPtr	piSymFac;
	ICOPS::IWarSymbolPtr		piSym;
	ICOPS::IWarSymEditablePtr	piSymE;
	ICOPS::IWarSymPropertyEditorPtr		piPrpEditor;

	bRes = pAppCxt->GetStockObject(_T("IWarSymFactory"), (void **) &piSymFac);
	if (!bRes)
	{
		ICOPS::CLog::AddLog(__FILE__, __LINE__, ICOPS::CLog::Log_Error, _T("�����ȣ���� ��ü ��� ����"));
		return;
	}

	bRes = pAppCxt->CreateObject(_T("IWarSymPropertyEditor"), (void **) &piPrpEditor);
	if (!bRes)
	{
		ICOPS::CLog::AddLog(__FILE__, __LINE__, ICOPS::CLog::Log_Error, _T("�����ȣ ���� ������Ʈ ��ü ��� ����"));
		return;
	}

	piPrpEditor->SetWarSymFactory(piSymFac);
	//piPrpEditor->NeedModifier(FALSE);	// �������� ���� ���� ������� �������� FALSE�� ����
	bRes = piPrpEditor->OpenSymbolSelector(m_strLastSymCode, this, &piSym);
	if (bRes)
	{
		m_strLastSymCode = piSym->GetSymbolCode();
		pItem = new CTest_OverItem;
		pItem->AddRef();
		pItem->m_piSym = piSym;

		ICOPS::IWarSymView *piSymView = piSym->GetSymbolView();
		if (piSymView!=NULL)
		{
			ICOPS::SWarSymDrawMode *pDrawMode = piSymView->GetDrawMode();
			//*pDrawMode = m_sDrawMode;

			ICOPS::CwsColorset *pColorset = piSymView->GetColorset();
			if (pColorset!=NULL)
			{
				//pColorset->SetNormalTextColor(Gdiplus::Color(255, 0, 0, 0));		// ���̺� ���� ����
				//pColorset->SetInverseTextColor(Gdiplus::Color(0, 255, 255, 255));	// ���̺� ���� ����� �����ϰ�
			}
			//piSymView->SetFontSizeScale(1.0f);		// ���̺� ���� ũ��
			//piSymView->SetLineWidthScale(2.0f);	// �� ����
		}

		bRes = pItem->QueryInterface(_T("IWarSymEditable"), (void **) &piSymE);
		if (bRes) m_piEditTool->SetAddingSymbol(piSymE);
	}
}


BOOL CTest_WarSymView::OnEraseBkgnd(CDC* pDC)
{
	// �������۸��� ����ϹǷ� ȭ�� ���ڰŸ� ������ ���� ȭ�� ������ ����
	return TRUE;
}


void CTest_WarSymView::OnDrawmodeBg()
{
	m_sDrawMode.isBgWhite = !m_sDrawMode.isBgWhite;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateDrawmodeBg(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.isBgWhite);
}


void CTest_WarSymView::OnDrawmodeColor()
{
	m_sDrawMode.isColorMode = !m_sDrawMode.isColorMode;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateDrawmodeColor(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.isColorMode);
}


void CTest_WarSymView::OnDrawmodeFillFrame()
{
	m_sDrawMode.fillFrame = !m_sDrawMode.fillFrame;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateDrawmodeFillFrame(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.fillFrame);
}


void CTest_WarSymView::OnDrawmodeShowFrame()
{
	m_sDrawMode.showFrame = !m_sDrawMode.showFrame;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateDrawmodeShowFrame(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.showFrame);
}


void CTest_WarSymView::OnDrawmodeShowIcon()
{
	m_sDrawMode.showIcon = !m_sDrawMode.showIcon;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateDrawmodeShowIcon(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.showIcon);
}


void CTest_WarSymView::OnLuminoDark()
{
	m_sDrawMode.luminance = ICOPS::WarSymLuminance_Dark;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateLuminoDark(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.luminance==ICOPS::WarSymLuminance_Dark);
}


void CTest_WarSymView::OnLuminoMedium()
{
	m_sDrawMode.luminance = ICOPS::WarSymLuminance_Medium;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateLuminoMedium(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.luminance==ICOPS::WarSymLuminance_Medium);
}


void CTest_WarSymView::OnLuminoLight()
{
	m_sDrawMode.luminance = ICOPS::WarSymLuminance_Light;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateLuminoLight(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.luminance==ICOPS::WarSymLuminance_Light);
}


void CTest_WarSymView::OnLuminoCustom()
{
	m_sDrawMode.luminance = ICOPS::WarSymLuminance_Custom;
	ApplyDrawModeToAll();
	Invalidate();
}


void CTest_WarSymView::OnUpdateLuminoCustom(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_sDrawMode.luminance==ICOPS::WarSymLuminance_Custom);
}


// ���ɽ���� ��ȣ��� ������ �о ȭ�鿡 ����
void CTest_WarSymView::OnTestSpeed()
{
	ClearTestData();

	BOOL		bRes;
	INT_PTR		nRes;
	CString		strPath, strCode, strMsg;
	CStringArray	straCodes;
	CStdioFile		file;

	CFileDialog		dlg(TRUE);

	nRes = dlg.DoModal();
	if (nRes!=IDOK) return;

	strPath = dlg.GetPathName();

	bRes = file.Open(strPath, CFile::modeRead | CFile::typeText | CFile::shareDenyNone);
	if (!bRes)
	{
		::AfxMessageBox(_T("������ �� �� �����ϴ�."), MB_OK | MB_ICONSTOP);
		return;
	}

	while (file.ReadString(strCode))
	{
		straCodes.Add(strCode);
	}


	// ��ȣ ����
	INT_PTR		inx, count, countSym;
	ICOPS::IWarSymbol	**ppSyms, *piSym;
	ICOPS::IWarSymView	*piSymView;
	ICOPS::IWarSymFactory	*piSymFac;

	CTest_WarSymApp				*pApp = (CTest_WarSymApp *) ::AfxGetApp();
	ICOPS::CAppContext			*pAppCxt = pApp->m_pAppCxt;

	bRes = pAppCxt->GetStockObject(_T("IWarSymFactory"), (void **) &piSymFac);
	if (!bRes)
	{
		ICOPS::CLog::AddLog(__FILE__, __LINE__, ICOPS::CLog::Log_Error, _T("�����ȣ���� ��ü ��� ����"));
		return;
	}

	count = straCodes.GetSize();
	ppSyms = m_piSyms.SetCount(count);

	countSym = 0;
	for (inx=0; inx<count; inx++)
	{
		strCode = straCodes.GetAt(inx);

		bRes = piSymFac->CreateSymbol(strCode, &piSym);
		if (bRes)
		{
			piSym->SetSymbolSize(7.0f);
			piSymView = piSym->GetSymbolView();
			if (piSymView!=NULL)
			{
				piSymView->CacheSymbolImage(m_bCacheSymImg);
				piSymView->SetAffiliation(strCode.GetAt(1));
				piSymView->LinkModifierInfo();
				piSymView->LinkFrameSymbol();
			}
			ppSyms[countSym] = piSym;
			countSym++;
		}
	}

	// ��ȣ ���� ��ġ �غ�
	INT_PTR		inxX, inxY, inxSym;
	Gdiplus::PointF		*pts;

	// ȭ�鿡 �յ��� ( ���� 37��, ���� 27��)
	CRect	rc;
	Gdiplus::REAL	w, h, dx, dy, sx, sy, x, y;
	INT_PTR		cx, cy;

	m_nTestMode = CTest_WarSymView::SpeedTest;
	GetClientRect(&rc);
	w = (Gdiplus::REAL) rc.Width();
	h = (Gdiplus::REAL) rc.Height();

	if (w==0.0f) w = 1000.0f;
	if (h==0.0f) h = 1000.0f;

	//cx = 38;
	//cy = 27;
	cy = (INT_PTR) (sqrt(countSym * h / w) + 0.5f) + 1;
	cx = (INT_PTR) (cy * w / h) - 1;

	dx = w / (cx + 1);
	dy = h / (cy + 1);
	sx = 0.5f * dx;
	sy = 0.5f * dy;

	inxSym = 0;
	pts = m_testPts.SetCount(countSym);
	strMsg.Format(_T("���üӵ� ����� ��ȣ ������ �Ϸ��߽��ϴ�. (%d ��)"), countSym);

	x = sx;
	for (inxX=0; inxX<cx && inxSym<countSym; inxX++)
	{
		y = sy;
		for (inxY=0; inxY<cy && inxSym<countSym; inxY++)
		{
			pts[inxSym].X = x;
			pts[inxSym].Y = y;
			inxSym++;

			if (inxSym>=countSym)
			{
				::AfxMessageBox(strMsg, MB_OK);
				Invalidate();
				return;
			}

			y += dy;
		}

		x += dx;
	}

	::AfxMessageBox(strMsg, MB_OK);
	Invalidate();
}


void CTest_WarSymView::OnTestClear()
{
	ClearTestData();
	m_nTestMode = CTest_WarSymView::None;
	Invalidate();
}


void CTest_WarSymView::ClearTestData()
{
	INT_PTR		inx, count;
	ICOPS::IWarSymbol	**ppSyms;

	count = m_piSyms.GetCount();
	ppSyms = m_piSyms.GetBuffer();

	for (inx=0;inx<count; inx++)
	{
		ppSyms[inx]->Release();
	}
	m_piSyms.SetCount(0);
	m_testPts.SetCount(0);

	if (mMemLeakTimer!=0) {
		KillTimer(mMemLeakTimer);
		mMemLeakTimer = 0;
	}
	mMemLeakTestOffset.X = 0.0f;
	mMemLeakTestOffset.Y = 0.0f;
}

#include <sys/timeb.h>
#include <time.h>


void CTest_WarSymView::DrawSpeedTest(Gdiplus::Graphics *pGrpx)
{
	INT_PTR		inx, count;
	Gdiplus::PointF		*pts;
	ICOPS::IWarSymbol	**ppiSyms;

	count = m_piSyms.GetCount();
	ppiSyms = m_piSyms.GetBuffer();
	pts = m_testPts.GetBuffer();


	struct _timeb tmStart;
	struct _timeb tmEnd;
#if _MFC_VER < 0x0800		// for Version .NET 2003
	_ftime(&tmStart);
#else
	_ftime_s(&tmStart);
#endif

	for (inx=0; inx<count; inx++)
	{
		ppiSyms[inx]->Draw(pGrpx, &pts[inx], 1, 1.0);
	}

#if _MFC_VER < 0x0800		// for Version .NET 2003
	_ftime(&tmEnd);
#else
	_ftime_s(&tmEnd);
#endif

	time_t milSec = tmEnd.time - tmStart.time;
	milSec *= 1000;
	milSec -= tmStart.millitm;
	milSec += tmEnd.millitm;

	CString msg;
	msg.Format(_T("%d�� ��ȣ ���� �ð� : %.3f"), count, milSec/1000.0f);
	//::AfxMessageBox(msg, MB_ICONINFORMATION | MB_OK);
	CTest_WarSymMainFrame *pMainFrm = (CTest_WarSymMainFrame *) ::AfxGetMainWnd();
	pMainFrm->m_wndStatusBar.SetPaneText(0, msg);
}


void CTest_WarSymView::OnEditDelete()
{
	// ���õ� ���� ����
	m_piEditTool->DeleteSelected(TRUE);
	Invalidate();
}


void CTest_WarSymView::OnEditProperty()
{
	CString		strSymCode;
	BOOL		bRes;
	CTest_OverItemPtr		pItem;
	INT_PTR selCount;
	ICOPS::IWarSymEditable			**ppSelected;
	ICOPS::IWarSymPropertyEditorPtr	piPrpEditor;

	CTest_WarSymApp			*pApp = (CTest_WarSymApp *) ::AfxGetApp();
	ICOPS::CAppContext		*pAppCxt = pApp->m_pAppCxt;
	ICOPS::IWarSymFactoryPtr	piSymFac;

	// ���õ� ���� ���
	selCount = m_piEditTool->GetSelectedCount();
	if (selCount == 0) {
		// ���õ� ���� ����
		return;
	}
	ppSelected = m_piEditTool->GetSelected();
	if (ppSelected==NULL) {
		// ���õ� ���� ����
		return;
	}

	ICOPS::CPtrArrayIWarSymbol piSyms;
	INT_PTR selIdx;
	for (selIdx = 0; selIdx < selCount; selIdx++) {
		pItem = NULL;
		bRes = ppSelected[selIdx]->QueryInterface(_T("CTest_OverItem"), (void **) &pItem);
		if (!bRes || pItem==NULL) {
			ASSERT(FALSE);
			return;	// ���õ� ������ �ڷ����� �ٸ�
		}
		piSyms.Add(pItem->m_piSym);
	}
	pItem = NULL;

	bRes = pAppCxt->GetStockObject(_T("IWarSymFactory"), (void **) &piSymFac);
	if (!bRes) return;

	bRes = pAppCxt->CreateObject(_T("IWarSymPropertyEditor"), (void **) &piPrpEditor);
	if (!bRes) return;

	BOOL bCommonLang = piSymFac->GetLanguage();
	CString strCaption = (bCommonLang ? _T("Symbol Attributes Settings") : _T("��ȣ�Ӽ� ����"));

	piPrpEditor->SetWarSymFactory(piSymFac);
	piPrpEditor->SetTargetSymbol(piSyms);
	//piPrpEditor->NeedModifier(FALSE);	// �������� ���� ���� ������� �������� FALSE�� ����
	piPrpEditor->OpenEditor(strCaption, this);

	Invalidate();
}


void CTest_WarSymView::OnPairingAdd()
{
	if (m_ptContext.X==0.0f || m_ptContext.Y==0.0f) {
		return;
	}

	INT_PTR count = m_piEditTool->GetSelectedCount();
	if (count<=0) {
		return;
	}

	BOOL bRes;
	INT_PTR inx;
	CTest_OverItemPtr pOverItem;
	ICOPS::IWarSymEditable	**ppiEditables = m_piEditTool->GetSelected();
	for (inx=0; inx<count; inx++) {
		pOverItem = NULL;
		bRes = ppiEditables[inx]->QueryInterface(_T("CTest_OverItem"), (void **) &pOverItem);
		if (bRes) {
			pOverItem->AddPairingPoint(m_ptContext);
		}
	}

	Invalidate();
}


void CTest_WarSymView::OnPairingReset()
{
	INT_PTR count = m_piEditTool->GetSelectedCount();
	if (count<=0) {
		return;
	}

	BOOL bRes;
	INT_PTR inx;
	CTest_OverItemPtr pOverItem;
	ICOPS::IWarSymEditable	**ppiEditables = m_piEditTool->GetSelected();
	for (inx=0; inx<count; inx++) {
		pOverItem = NULL;
		bRes = ppiEditables[inx]->QueryInterface(_T("CTest_OverItem"), (void **) &pOverItem);
		if (bRes) {
			pOverItem->ResetPairingPoints();
		}
	}

	Invalidate();
}


void CTest_WarSymView::OnCacheSymimg()
{
	INT_PTR		inx, count;
	ICOPS::IWarSymbol	**ppSyms;

	m_bCacheSymImg = !m_bCacheSymImg;

	count = m_piSyms.GetCount();
	ppSyms = m_piSyms.GetBuffer();

	for (inx=0;inx<count; inx++)
	{
		ppSyms[inx]->CacheSymbolImage(m_bCacheSymImg);
	}

	CTest_WarSymDoc	*pDoc = GetDocument();
	CTest_OverItem	*pOverItem;

	count = pDoc->m_parOverItems.GetSize();
	if (count>0)
	{
		for (inx=0; inx<count; inx++)
		{
			pOverItem = pDoc->m_parOverItems.GetAt(inx);
			pOverItem->m_piSym->CacheSymbolImage(m_bCacheSymImg);
		}
	}

	Invalidate();
}


void CTest_WarSymView::OnUpdateCacheSymimg(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_bCacheSymImg);
}


void CTest_WarSymView::OnCopySelected()
{
	BOOL	bRes;
	INT_PTR		inx, count;
	ICOPS::IWarSymEditable	**ppiEditables;
	CTest_OverItemPtr	pOverItem, pNewOverItem;
	CTest_WarSymDoc	*pDoc = GetDocument();

	count = m_piEditTool->GetSelectedCount();
	ppiEditables = m_piEditTool->GetSelected();

	for (inx=0; inx<count; inx++)
	{
		pOverItem = NULL;
		pNewOverItem = NULL;
		bRes = ppiEditables[inx]->QueryInterface(_T("CTest_OverItem"), (void **) &pOverItem);
		if (bRes)
		{
			bRes = pOverItem->Clone(&pNewOverItem);
			if (bRes)
			{
				pDoc->m_parOverItems.Add(pNewOverItem);
				pNewOverItem->AddRef();
			}
		}
	}

	m_piEditTool->OnChangeEditableList();
}


void CTest_WarSymView::OnUpdateCopySelected(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(m_piEditTool->GetSelectedCount()>0);
}


void CTest_WarSymView::OnEditRefreshMode()
{
	m_piEditTool->SetEditingMode(RefreshOnChange);
}


void CTest_WarSymView::OnUpdateRefreshMode(CCmdUI *pCmdUI)
{
	EWarSymEditingMode	eEditMode;

	eEditMode = m_piEditTool->GetEditingMode();
	pCmdUI->SetCheck(eEditMode==RefreshOnChange);
}


void CTest_WarSymView::OnInverseMode()
{
	m_piEditTool->SetEditingMode(UseInverseDraw);
}


void CTest_WarSymView::OnUpdateInverseMode(CCmdUI *pCmdUI)
{
	EWarSymEditingMode	eEditMode;

	eEditMode = m_piEditTool->GetEditingMode();
	pCmdUI->SetCheck(eEditMode==UseInverseDraw);
}


void CTest_WarSymView::OnUseCommonLang()
{
	CTest_WarSymApp		*pApp = (CTest_WarSymApp *) ::AfxGetApp();
	if (pApp->m_piSymFac==NULL) {
		return;
	}

	BOOL bCommonLang = pApp->m_piSymFac->GetLanguage();
	pApp->m_piSymFac->SetLanguage(!bCommonLang);

	// ��ȣ�ڷ� �ٽ� �б� ���� ��ȣ ��ü�� ��� �Ҹ��ؾ� �Ѵ�.
	// �Ҹ���� ���� ��ȣ��ü ���� ��� �޸� ���� ������ �߻��Ѵ�.
	CTest_WarSymDoc	*pDoc = GetDocument();
	m_piEditTool->DeselectAll();
	pDoc->DeleteContents();
	ClearTestData();
	m_piEditTool->OnChangeEditableList();

	// ���� ���� ��ȣ�ڷḦ �����Ͽ� ����ϴ� ��ȣ�� �����ϱ� ����
	// ��ȣ�ڷḦ �ٽ� �д´�.
	pApp->m_piSymFac->ReloadSymbolData();
	Invalidate();
}


void CTest_WarSymView::OnUpdateUseCommonLang(CCmdUI *pCmdUI)
{
	CTest_WarSymApp		*pApp = (CTest_WarSymApp *) ::AfxGetApp();
	if (pApp->m_piSymFac==NULL) {
		pCmdUI->Enable(FALSE);
		return;
	}

	pCmdUI->Enable(TRUE);
	pCmdUI->SetCheck(pApp->m_piSymFac->GetLanguage());
}


//void CTest_WarSymView::OnDebugPatternLine()
//{
//	ClearTestData();
//	m_nTestMode = CTest_WarSymView::PatternLineTest;
//	Invalidate();
//}


void CTest_WarSymView::OnDebugPatternLine()
{
	ClearTestData();
	m_nTestMode = CTest_WarSymView::PatternLineTest;
	Invalidate();
}


//#define PTN_HALF_WIDTH 50

void CTest_WarSymView::DrawPatternLineTest(Gdiplus::Graphics *pGrpx)
{
	//if (mTestPtnIcon==NULL) {
	//	Gdiplus::Point iconPoints[10];
	//	iconPoints[0].X = 0;
	//	iconPoints[0].Y = -PTN_HALF_WIDTH;
	//	iconPoints[1].X = 0;
	//	iconPoints[1].Y = PTN_HALF_WIDTH;
	//	iconPoints[2].X = 3;
	//	iconPoints[2].Y = -PTN_HALF_WIDTH;
	//	iconPoints[3].X = 3;
	//	iconPoints[3].Y = PTN_HALF_WIDTH;
	//	iconPoints[4].X = 6;
	//	iconPoints[4].Y = -PTN_HALF_WIDTH;
	//	iconPoints[5].X = 6;
	//	iconPoints[5].Y = PTN_HALF_WIDTH;
	//	iconPoints[6].X = 9;
	//	iconPoints[6].Y = -PTN_HALF_WIDTH;
	//	iconPoints[7].X = 9;
	//	iconPoints[7].Y = PTN_HALF_WIDTH;
	//	iconPoints[8].X = 12;
	//	iconPoints[8].Y = -PTN_HALF_WIDTH;
	//	iconPoints[9].X = 12;
	//	iconPoints[9].Y = PTN_HALF_WIDTH;

	//	mTestPtnIcon = new ICOPS::PatternLine::Icon();
	//	mTestPtnIcon->setDimension(PTN_HALF_WIDTH, 9);
	//	mTestPtnIcon->setIconPoints(iconPoints, 4);

	//	ICOPS::PatternLine::Icon::Shape sh;
	//	int inx;

	//	for (inx=0; inx<2; inx++) {
	//		sh.mLine = TRUE;
	//		sh.mFill = FALSE;
	//		sh.mLineWidth = 1;
	//		sh.mPointCount = 2;
	//		sh.mPointOffset = 2 * inx;
	//		mTestPtnIcon->addShape(&sh);
	//	}
	//}
	if (mTestPtnIcon==NULL) {
		Gdiplus::Point *iconPoints = new Gdiplus::Point[17];
		iconPoints[0].X = 0;
		iconPoints[0].Y = 0;
		iconPoints[1].X = 1;
		iconPoints[1].Y = -4;
		iconPoints[2].X = 2;
		iconPoints[2].Y = -6;
		iconPoints[3].X = 3;
		iconPoints[3].Y = -7;
		iconPoints[4].X = 4;
		iconPoints[4].Y = -7;
		iconPoints[5].X = 5;
		iconPoints[5].Y = -6;
		iconPoints[6].X = 6;
		iconPoints[6].Y = -4;
		iconPoints[7].X = 7;
		iconPoints[7].Y = 0;
		iconPoints[8].X = 8;
		iconPoints[8].Y = 4;
		iconPoints[9].X = 9;
		iconPoints[9].Y = 6;
		iconPoints[10].X = 10;
		iconPoints[10].Y = 7;
		iconPoints[11].X = 11;
		iconPoints[11].Y = 7;
		iconPoints[12].X = 12;
		iconPoints[12].Y = 6;
		iconPoints[13].X = 13;
		iconPoints[13].Y = 4;
		iconPoints[14].X = 14;
		iconPoints[14].Y = 0;
		iconPoints[15].X = 9;
		iconPoints[15].Y = -7;
		iconPoints[16].X = 5;
		iconPoints[16].Y = 7;

		mTestPtnIcon = new ICOPS::PatternLine::Icon();
		mTestPtnIcon->setDimension(14, 7);
		mTestPtnIcon->setIconPoints(iconPoints, 17);

		ICOPS::PatternLine::Icon::Shape *sh;

		sh = new ICOPS::PatternLine::Icon::Shape();
		sh->mLine = TRUE;
		sh->mFill = FALSE;
		sh->mConnect = TRUE;
		sh->mLineWidth = 1;
		sh->mPointCount = 15;
		sh->mPointOffset = 0;
		mTestPtnIcon->addShape(sh);

		sh = new ICOPS::PatternLine::Icon::Shape();
		sh->mLine = TRUE;
		sh->mFill = FALSE;
		sh->mConnect = FALSE;
		sh->mLineWidth = 1;
		sh->mPointCount = 2;
		sh->mPointOffset = 15;
		mTestPtnIcon->addShape(sh);
	}

	static int count = 0;
	static Gdiplus::Point points[7];
	if (count==0) {
		count = 6;
		points[0].X = 100;
		points[0].Y = 300;
		points[1].X = 300;
		points[1].Y = 100;
		points[2].X = 500;
		points[2].Y = 100;
		points[3].X = 700;
		points[3].Y = 300;
		points[4].X = 500;
		points[4].Y = 500;
		points[5].X = 300;
		points[5].Y = 500;
		points[6].X = 100;
		points[6].Y = 300;
	}

	//static int count = 0;
	//static Gdiplus::Point points[2];
	//if (count==0) {
	//	count = 2;
	//	points[0].X = 100;
	//	points[0].Y = 200;
	//	points[1].X = 200;
	//	points[1].Y = 100;
	//}

	Gdiplus::Pen penCenter(Gdiplus::Color(255, 255, 0, 0), 1.0f);
	pGrpx->DrawLines(&penCenter, points, count);

	Gdiplus::Pen pen(Gdiplus::Color(255, 0, 0, 255), 1.0f);
	Gdiplus::SolidBrush br(Gdiplus::Color(255, 255, 0, 0));
	ICOPS::PatternLine ptnLine;

	ptnLine.draw(pGrpx, 14.0, 2.0, &pen, &br, mTestPtnIcon, points, count, TRUE, NULL, 0);
}

static int gMemLeakDispCount = 0;

void CTest_WarSymView::OnDebugMemLeak()
{
	ClearTestData();
	m_nTestMode = CTest_WarSymView::MemoryLeakTest;
	gMemLeakDispCount = 0;
	mMemLeakTimer = SetTimer(1, 10, NULL);
}


void CTest_WarSymView::OnToggleTgLabel(UINT nID)
{
	if (mTgLabelTarget==NULL) {
		ASSERT(FALSE);
		return;
	}

	INT_PTR labelInx = nID - ID_TGLABEL_START;
	if (labelInx<0) {
		ASSERT(FALSE);
		mTgLabelTarget = NULL;
		return;
	}

	CStringArray straLabels;
	mTgLabelTarget->EnumLabels(straLabels);
	INT_PTR count = straLabels.GetSize();
	if (labelInx>=count) {
		ASSERT(FALSE);
		mTgLabelTarget = NULL;
		return;
	}

	CString strLabel;
	strLabel = straLabels.GetAt(labelInx);
	BOOL bShow = mTgLabelTarget->IsShowLabel(strLabel);
	mTgLabelTarget->ShowLabel(strLabel, !bShow);

	mTgLabelTarget = NULL;
	Invalidate();
}


void CTest_WarSymView::OnTimer(UINT_PTR nIDEvent)
{
	if (nIDEvent==mMemLeakTimer) {
		KillTimer(mMemLeakTimer);
		UpdateMemoryLeakTest();
		mMemLeakTimer = SetTimer(1, 10, NULL);
	}

	CScrollView::OnTimer(nIDEvent);
}


void CTest_WarSymView::UpdateMemoryLeakTest()
{
	CRect rc;
	GetClientRect(&rc);
	int w2 = rc.Width() / 2;
	int h2 = rc.Height() / 2;

	mMemLeakTestOffset.X += mMemLeakTestOffsetDir.Width;
	mMemLeakTestOffset.Y += mMemLeakTestOffsetDir.Height;

	if (mMemLeakTestOffsetDir.Width>0.0f) {
		if (mMemLeakTestOffset.X>=w2) {
			mMemLeakTestOffset.X = (Gdiplus::REAL) w2;
			mMemLeakTestOffsetDir.Width = -2.0f;
		}
	} else {
		if (mMemLeakTestOffset.X<=-w2) {
			mMemLeakTestOffset.X = (Gdiplus::REAL) -w2;
			mMemLeakTestOffsetDir.Width = 2.0f;
		}
	}

	if (mMemLeakTestOffsetDir.Height>0.0f) {
		if (mMemLeakTestOffset.Y>=h2) {
			mMemLeakTestOffset.Y = (Gdiplus::REAL) h2;
			mMemLeakTestOffsetDir.Height = -2.0f;
		}
	} else {
		if (mMemLeakTestOffset.Y<=-h2) {
			mMemLeakTestOffset.Y = (Gdiplus::REAL) -h2;
			mMemLeakTestOffsetDir.Height = 2.0f;
		}
	}

	Invalidate();
}


void CTest_WarSymView::DrawMemoryLeakTest(Gdiplus::Graphics *pGrpx)
{
	ICOPS::IWarSymFactoryPtr piSymFac;

	CTest_WarSymApp *pApp = (CTest_WarSymApp *) ::AfxGetApp();
	ICOPS::CAppContext *pAppCxt = pApp->m_pAppCxt;

	BOOL bRes = pAppCxt->GetStockObject(_T("IWarSymFactory"), (void **) &piSymFac);
	if (!bRes) {
		ICOPS::CLog::AddLog(__FILE__, __LINE__, ICOPS::CLog::Log_Error, _T("�����ȣ���� ��ü ��� ����"));
		return;
	}

	CRect rc;
	GetClientRect(&rc);
	Gdiplus::REAL tX = 0.5f * (rc.left + rc.right) + mMemLeakTestOffset.X;
	Gdiplus::REAL tY = 0.5f * (rc.top + rc.bottom) + mMemLeakTestOffset.Y;

	ICOPS::IWarSymbolPtr piSym;
	CString strCode(_T("G*G*GLB---****X"));

	bRes = piSymFac->CreateSymbol(strCode, &piSym);
	if (bRes) {
		Gdiplus::PointF *pts = new Gdiplus::PointF[5];
		pts[0].X = -100.0f + tX;	pts[0].Y = -100.0f + tY;
		pts[1].X = 0.0f + tX;		pts[1].Y = -100.0f + tY;
		pts[2].X = 0.0f + tX	;	pts[2].Y = 0.0f + tY;
		pts[3].X = 100.0f + tX;	pts[3].Y = 0.0f + tY;
		pts[4].X = 100.0f + tX;	pts[4].Y = 100.0f + tY;

		ICOPS::IWarSymView *pSymView = piSym->GetSymbolView();
		ICOPS::CwsModifier *pMod = pSymView->GetModifier();
		pMod->Set(ICOPS::CwsModifier::B, _T("E"));
		pMod->Set(ICOPS::CwsModifier::T, _T("12"));
		pMod->Set(ICOPS::CwsModifier::T1, _T("23"));
		pSymView->LinkModifierInfo();

		piSym->Draw(pGrpx, pts, 5, 1.0);
		delete[] pts;

		CString msg;
		msg.Format(_T("Draw %s %d times."), strCode, gMemLeakDispCount++);
		CTest_WarSymMainFrame *pMainFrm = (CTest_WarSymMainFrame *) ::AfxGetMainWnd();
		pMainFrm->m_wndStatusBar.SetPaneText(0, msg);
	}	
}

void CTest_WarSymView::MakeMemLeakTestPoints(Gdiplus::PointF *pPoints, INT_PTR count)
{
	if (pPoints==NULL || count<1) {
		return;
	}

	RECT rc;
	GetClientRect(&rc);
	int cx = (rc.left + rc.right) / 2;
	int cy = (rc.top + rc.bottom) / 2;

	INT_PTR inx;
	for (inx=0; inx<count; inx++) {
		pPoints[inx].X += mMemLeakTestOffset.X;
		pPoints[inx].Y += mMemLeakTestOffset.Y;
	}
}

void CTest_WarSymView::OnDestroy()
{
	if (mMemLeakTimer!=0) {
		KillTimer(mMemLeakTimer);
		mMemLeakTimer = 0;
	}
	CScrollView::OnDestroy();
}
